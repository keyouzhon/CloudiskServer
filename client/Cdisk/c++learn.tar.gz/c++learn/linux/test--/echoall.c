#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<fcntl.h>
#include<string.h>
#include<pthread.h>
int main(int argc,char** argv)
{
    for(int i=0;i<argc;i++)
    {
        puts(argv[i]);
    }
    //print environment variables
    extern char** environ ;
    for(char** i=environ;*i!=NULL;i++)
    {
        puts(*i);
    }
    return 0;
}

#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<fcntl.h>
#include<string.h>
#include<pthread.h>
#include<sys/wait.h>
void print_wstatus(int status)
{
    if(WIFEXITED(status))
    {
        printf("exit_code:%d\n",WIFEXITED(status));
    }
    if(WIFSIGNALED(status))
    {
        printf("term_sig:%d\n",WIFSIGNALED(status));
    }
#ifdef WCOREDUMP
    if(WCOREDUMP(status))
    {
        printf("core dump enabled\n");
    }
#endif
    printf("\n");
}
int main()
{
    pid_t pid = fork();
    int status;
    pid_t childPid;
    switch (pid)
    {
    case -1:
         perror("fork() error:\n");
    case 0:
         printf("child:%d\n",getpid());
         return 0;
    default:
         childPid = wait(&status);
         if (childPid>0)
         {
             printf("Parent:%d terminated\n",childPid);
             print_wstatus(status);
         }
         exit(0);

    }
    return 0;
}

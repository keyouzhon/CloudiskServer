#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<fcntl.h>
#include<string.h>
#include<pthread.h>
int main()
{
    printf("pid:%d\nppid:%d\n",getpid(),getppid());
    for(int i=0;i<3;++i)
    {
        fork();
        printf("a");
    }
    printf("\n");
    return 0;
}

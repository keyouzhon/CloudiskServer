#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<fcntl.h>
#include<string.h>
#include<pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <unistd.h>

// 线程执行函数
// 必须接受 void* 参数，并返回 void*
void *thread_function(void *arg) {
    char *message = (char *)arg;
    printf("Thread ID: %lu\n", (unsigned long)pthread_self());
    printf("Thread received: %s\n", message);
    sleep(1); 
    
    // 线程通过 return 或 pthread_exit 返回结果
    pthread_exit((void*)"Thread finished successfully.");
}

int main() {
    pthread_t thread_id;
    const char *message = "Hello from main process";
    void *thread_result; // 用于接收线程返回值

    printf("Main process starting...\n");

    // 创建线程
    int res = pthread_create(&thread_id, NULL, thread_function, (void *)message);
    
    if (res != 0) {
        perror("Thread creation failed");
        return 1;
    }

    // 主线程等待子线程结束
    printf("Main process waiting for thread...\n");
    res = pthread_join(thread_id, &thread_result);
    
    if (res != 0) {
        perror("Thread join failed");
        return 1;
    }

    // 打印线程的返回值
    printf("Thread joined. Result was: %s\n", (char *)thread_result);

    return 0;
}

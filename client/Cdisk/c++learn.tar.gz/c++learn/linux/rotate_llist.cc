#include<iostream>
template<class T>
struct Node
{
    Node<T> * next;
    T data;
    node<T>(T _data)
    :data(_data),next(nullptr)
    {}
};

template<class T>
class linkedList
{
    
};

#include<iostream>
template<class T>
void display(T t)
{
    std::cout<<typeid(t).name()<<"-->"<<t<<std::endl;
};
int main()
{
    int p(10);
    display(&p);    
    int * pp(&p);
    void * cp{reinterpret_cast<void*>(pp)};
    display(pp);
    //void*没有定义算术操作
    //因为编译器无法确定这个void* 指针指向什么类型
    for(int i=0;i<4;i++)
    {
        display(reinterpret_cast<void*>(reinterpret_cast<char*>(cp)+i));
    }
    return 0;

}

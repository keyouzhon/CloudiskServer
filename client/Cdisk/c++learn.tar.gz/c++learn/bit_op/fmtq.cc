
#define Frequently_Met_Test_Questions_cc
#include<iostream>
//!!!!!逻辑运算符的优先级小于判断运算符
//1,Determine whether a number is odd:
template<class T>
bool odd_number(T x)
{
    return (x&1)!=0;
}

//2,determine whether a number is the power of two
template<class T>
bool power_otwo(T x)
{
    if(x<0)
        return 0;
    else
        //x-1会使得二进制表示的最低有效位变为0，之后的全为1
        //x&(x-1)会将最低有效位清除，从而只剩最低有效位左边的1
        return (x&(x-1))==0;
}
//3,find the least significant bit:
template<class T>
bool find_lsb(T x)
{
    //将一个数取反则所有位置的数都与原来位置相反，
    //再加1则使得最低有效位和原来的位置相同，故而考虑&
    return x&(~x+1);//-x=~x+1;
    // return x&-x;
}
//4,swap the value of two integers:
//b=a+b;a=a^b
//a=b-a;b=a^b
//b=b-a;a=a^b
//共性是先保存两个数的某方面的状态
template<class T>
void swap_int(T& x,T& y)
{
    x=x^y;
    y=x^y;
    x=x^y;
}
//5,find the only element that appear once,while the other all appear twice:
template<class T,int N>
T find_only_once(T (&arr)[N])
{
    T temp=0;
    for(int i=0;i<N;++i)
    {
        temp^=arr[i];   
    }
    return temp;
}
//6,finde the only two elements that appear once,while the other
//all appear twice:
template<class T,int N>
std::pair<T,T> find_two_once(T (&arr)[N])
{
    T temp=0;
    for(int i=0;i<N;i++)
    {
        temp^=arr[i];
    }
    T mask=temp&-temp;
    T tempp=temp=0;
    for(int i=0;i<N;i++)
    {
        if((arr[i]&mask)==0)
            temp^=arr[i];
        else
            tempp^=arr[i];
    }
    return std::pair<T,T>{temp,tempp};
    //return make_pair(temp,tempp);
}
int main()
{
    std::cout<<odd_number(3)<<std::endl;
    std::cout<<power_otwo(234279839)<<std::endl;
    std::cout<<find_lsb(821498213947)<<std::endl;
    int a=89,b=87;
    swap_int(a,b);
    std::cout<<a<<" and "<<b<<std::endl;
    int c[11]{990,990,877,1,877,2,2,3,3,4,4};
    std::cout<<find_only_once<int,11>(c)<<std::endl;
    int d[12]{990,990,877,1,877,2,2,3,3,4,4,10000};
    std::cout<<find_two_once<int,12>(d).first
             <<find_two_once<int,12>(d).second<<std::endl;
}

#include "Line.hpp"
#include<iostream>
void test0()
{
	Line ll(0,1,2,3);
	ll.printLine();
}
int main()
{
	test0();
	return 0;
}

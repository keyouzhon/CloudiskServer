#include "Line.hpp"
#include<iostream>
using std::ostream;
class Line::LineImpl
{
public:
	//Point称为Line的成员类型
	class Point
	{
	public:
		Point(int x=0,int y=0)
			:_ix(x),_iy(y)
		{
			std::cout<<"Point(int,int)"<<std::endl;
		}
		~Point()
		{
			std::cout<<"~Point()"<<std::endl;
		}
		void print()
		{
			std::cout<<"("<<_ix<<","<<_iy<<")";
		}
	private:
		int _ix;
		int _iy;
		static int _iz;

	};
public:
	LineImpl(int x1,int y1,int x2,int y2)
		:_pt1(x1,y1),_pt2(x2,y2)
	{
		std::cout<<"Line()"<<std::endl;
	}
	LineImpl()
	{
		std::cout<<"~Line()"<<std::endl;
	}
	
	Point _pt1;
	Point _pt2;

	
};
//内部类的静态数据成员必须放在外部类下面定义；
int Line::LineImpl::Point::_iz=0;

Line::Line(int x1,int y1,int x2,int y2)
	:_pimpl(new LineImpl(x1,y1,x2,y2))
	{std::cout<<"Line(int*4)"<<std::endl;}
Line::~Line()
{
	std::cout<<"~Line()"<<std::endl;
	if(_pimpl)
	{
		delete _pimpl;
		_pimpl=nullptr;
	}
}

void Line::printLine() const
{
	_pimpl->_pt1.print();
	std::cout<<"--------->";
	_pimpl->_pt2.print();
	std::cout<<std::endl;
}

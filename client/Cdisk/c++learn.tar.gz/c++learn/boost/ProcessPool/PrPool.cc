#include "PrPool.h"
#include <iostream>
#include <sys/socket.h>
#include <sys/wait.h>
#include <csignal>
#include <stdexcept>
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/sendfile.h>
#include <cstring>
#include <fstream>
#include <sstream>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>

// --- WorkerProcess Implementation ---
WorkerProcess::WorkerProcess() {
    if (socketpair(AF_UNIX, SOCK_STREAM, 0, pipe_fd) < 0) {
        perror("socketpair");
        throw std::runtime_error("Failed to create socketpair for worker.");
    }
}

WorkerProcess::~WorkerProcess() {
    close_pipes();
}

void WorkerProcess::close_pipes() {
    if (pipe_fd[0] != -1) { close(pipe_fd[0]); pipe_fd[0] = -1; }
    if (pipe_fd[1] != -1) { close(pipe_fd[1]); pipe_fd[1] = -1; }
}


// --- ProcessPool Implementation ---
ProcessPool::ProcessPool(int process_num, const std::string& image_path)
    : _process_num(process_num),
      _next_worker_idx(0),
      _image_path(image_path) {
    if (_process_num <= 0) {
        throw std::invalid_argument("Process number must be greater than 0.");
    }
    _workers.resize(_process_num);
}

ProcessPool::~ProcessPool() {
    for (const auto& worker : _workers) {
        if (worker.pid > 0) {
            kill(worker.pid, SIGTERM);
        }
    }
}

void ProcessPool::setup_workers() {
    for (int i = 0; i < _process_num; ++i) {
        pid_t pid = fork();
        if (pid < 0) {
            perror("fork");
            throw std::runtime_error("Failed to fork worker process.");
        } else if (pid == 0) { // 子进程
            // 子进程关闭父进程端的管道
            close(_workers[i].pipe_fd[0]);
            worker_loop(i);
            exit(0);
        } else { // 主进程
            _workers[i].pid = pid;
            // 主进程关闭子进程端的管道
            close(_workers[i].pipe_fd[1]);
        }
    }
}

void ProcessPool::worker_loop(int worker_idx) {
    int pipe_read_fd = _workers[worker_idx].pipe_fd[1];
    std::cout << "Worker " << getpid() << " started." << std::endl;
    while (true) {
        int client_fd = recv_fd(pipe_read_fd);
        if (client_fd < 0) {
            std::cerr << "Worker " << getpid() << ": Failed to receive fd. Exiting." << std::endl;
            break;
        }
        std::cout << "Worker " << getpid() << " received client fd " << client_fd << std::endl;
        handle_client_connection(client_fd, _image_path);
        close(client_fd); // 完成任务后关闭连接
    }
    close(pipe_read_fd);
}

void ProcessPool::handle_client_connection(int client_fd, const std::string& image_path) {
    // 1. (极简)读取HTTP请求
    char request_buffer[1024] = {0};
    recv(client_fd, request_buffer, sizeof(request_buffer) - 1, 0);
    // 实际项目中需要更复杂的解析，这里我们假设所有请求都是有效的GET
    
    // 2. 准备图片文件
    std::ifstream image_file(image_path, std::ios::binary | std::ios::ate);
    if (!image_file.is_open()) {
        std::cerr << "Worker " << getpid() << ": Failed to open image file: " << image_path << std::endl;
        // 可以发送一个 404 Not Found 响应
        const char* response_404 = "HTTP/1.1 404 Not Found\r\nContent-Length: 0\r\n\r\n";
        send(client_fd, response_404, strlen(response_404), 0);
        return;
    }

    std::streamsize file_size = image_file.tellg();
    image_file.seekg(0, std::ios::beg);

    // 3. 构建并发送HTTP响应头
    std::stringstream response_header;
    response_header << "HTTP/1.1 200 OK\r\n";
    response_header << "Content-Type: image/jpeg\r\n";
    response_header << "Content-Length: " << file_size << "\r\n";
    response_header << "Connection: close\r\n";
    response_header << "\r\n";
    
    std::string header_str = response_header.str();
    send(client_fd, header_str.c_str(), header_str.length(), 0);

    // 4. 分片发送图片文件内容
    char buffer[4096];
    while (image_file.read(buffer, sizeof(buffer))) {
        if (send(client_fd, buffer, image_file.gcount(), 0) < 0) {
            perror("send image fragment");
            break;
        }
    }
    // 发送最后一块不足4096字节的数据
    if (image_file.gcount() > 0) {
        send(client_fd, buffer, image_file.gcount(), 0);
    }
    
    std::cout << "Worker " << getpid() << ": Sent image completely." << std::endl;
}


void ProcessPool::run(int listen_fd) {
    setup_workers();
    std::cout << "Manager " << getpid() << " started. Listening for connections..." << std::endl;

    while (true) {
        struct sockaddr_in client_addr;
        socklen_t client_addr_len = sizeof(client_addr);
        int client_fd = accept(listen_fd, (struct sockaddr*)&client_addr, &client_addr_len);
        if (client_fd < 0) {
            perror("accept");
            continue;
        }

        std::cout << "Manager: Accepted new connection from " 
                  << inet_ntoa(client_addr.sin_addr) << " with fd " << client_fd << std::endl;

        // 轮询选择一个工作进程
        int worker_idx = _next_worker_idx;
        _next_worker_idx = (_next_worker_idx + 1) % _process_num;

        // 将新的客户端fd发送给工作进程
        if (!send_fd(_workers[worker_idx].pipe_fd[0], client_fd)) {
            std::cerr << "Manager: Failed to send fd to worker." << std::endl;
        }

        // 主进程关闭自己持有的客户端fd，因为所有权已经转移
        close(client_fd);
    }
}

// --- FD Passing Helper Functions ---
bool ProcessPool::send_fd(int sock_fd, int fd_to_send) {
    struct msghdr msg = {0};
    struct cmsghdr *cmsg;
    char buf[CMSG_SPACE(sizeof(int))];
    memset(buf, 0, sizeof(buf));
    char dummy = '*';
    struct iovec io;
    io.iov_base = &dummy;
    io.iov_len = sizeof(dummy);

    msg.msg_iov = &io;
    msg.msg_iovlen = 1;
    msg.msg_control = buf;
    msg.msg_controllen = sizeof(buf);

    cmsg = CMSG_FIRSTHDR(&msg);
    cmsg->cmsg_level = SOL_SOCKET;
    cmsg->cmsg_type = SCM_RIGHTS;
    cmsg->cmsg_len = CMSG_LEN(sizeof(int));

    *((int *) CMSG_DATA(cmsg)) = fd_to_send;
    return sendmsg(sock_fd, &msg, 0) >= 0;
}

int ProcessPool::recv_fd(int sock_fd) {
    struct msghdr msg = {0};
    struct cmsghdr *cmsg;
    char buf[CMSG_SPACE(sizeof(int))];
    char dummy;
    struct iovec io;
    io.iov_base = &dummy;
    io.iov_len = sizeof(dummy);

    msg.msg_iov = &io;
    msg.msg_iovlen = 1;
    msg.msg_control = buf;
    msg.msg_controllen = sizeof(buf);

    if (recvmsg(sock_fd, &msg, 0) <= 0) {
        return -1;
    }

    for (cmsg = CMSG_FIRSTHDR(&msg); cmsg != NULL; cmsg = CMSG_NXTHDR(&msg, cmsg)) {
        if (cmsg->cmsg_level == SOL_SOCKET && cmsg->cmsg_type == SCM_RIGHTS) {
            return *((int *) CMSG_DATA(cmsg));
        }
    }
    return -1;
}

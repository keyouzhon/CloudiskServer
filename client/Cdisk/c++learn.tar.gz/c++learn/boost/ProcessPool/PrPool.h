#ifndef __PrPool_H__
#define __PrPool_H__

#include <vector>
#include <string>
#include <unistd.h>
#include <functional>

// 封装工作进程的信息
class WorkerProcess {
public:
    WorkerProcess();
    ~WorkerProcess();
    void close_pipes();

    pid_t pid = -1;
    // 用于主进程向子进程通信的Unix域套接字
    int pipe_fd[2] = {-1, -1}; 
};

// 进程池类
class ProcessPool {
public:
    ProcessPool(int process_num, const std::string& image_path);
    ~ProcessPool();

    // 禁用拷贝和赋值
    ProcessPool(const ProcessPool&) = delete;
    ProcessPool& operator=(const ProcessPool&) = delete;

    // 运行进程池，主进程调用
    void run(int listen_fd);

private:
    void setup_workers();
    void worker_loop(int worker_idx);

    // 静态成员函数，作为工作进程的业务逻辑入口
    static void handle_client_connection(int client_fd, const std::string& image_path);
    
    // 静态成员函数，用于传递和接收文件描述符
    static bool send_fd(int sock_fd, int fd_to_send);
    static int recv_fd(int sock_fd);

private:
    int _process_num;
    int _next_worker_idx;
    std::string _image_path;
    std::vector<WorkerProcess> _workers;
};


#endif

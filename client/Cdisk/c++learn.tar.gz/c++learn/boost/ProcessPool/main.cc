#include "PrPool.h"
#include <iostream>
#include <sys/socket.h>
#include <netinet/in.h>
#include <unistd.h>
#include <fstream>

const int PORT = 8888;
const int PROCESS_NUM = 4;
const std::string IMAGE_PATH = "test_image.jpg"; // 请确保这个图片文件存在

int main() {

    // 1. 创建监听套接字
    int listen_fd = socket(AF_INET, SOCK_STREAM, 0);
    if (listen_fd < 0) {
        perror("socket");
        return 1;
    }

    // 设置地址复用
    int opt = 1;
    setsockopt(listen_fd, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt));

    // 2. 绑定地址
    struct sockaddr_in server_addr;
    server_addr.sin_family = AF_INET;
    server_addr.sin_addr.s_addr = htonl(INADDR_ANY);
    server_addr.sin_port = htons(PORT);
    if (bind(listen_fd, (struct sockaddr*)&server_addr, sizeof(server_addr)) < 0) {
        perror("bind");
        close(listen_fd);
        return 1;
    }

    // 3. 监听
    if (listen(listen_fd, 128) < 0) {
        perror("listen");
        close(listen_fd);
        return 1;
    }
    
    std::cout << "Server is listening on port " << PORT << std::endl;

    try {
        // 4. 创建并运行进程池
        ProcessPool pool(PROCESS_NUM, IMAGE_PATH);
        pool.run(listen_fd);
    } catch (const std::exception& e) {
        std::cerr << "Caught exception: " << e.what() << std::endl;
        close(listen_fd);
        return 1;
    }

    close(listen_fd);
    return 0;
}


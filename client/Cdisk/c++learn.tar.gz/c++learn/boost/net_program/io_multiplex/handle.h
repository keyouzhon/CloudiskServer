#ifndef __handle_H__
#define __handle_H__
#include <stdio.h>    // 基础 I/O，用于 fprintf
#include <stdlib.h>   // 用于 EXIT_FAILURE
#include <string.h>   // 用于 strerror
#include <errno.h>    // 用于 errno 全局变量

// ----------------------------------------------------
// 宏定义 1: 致命错误处理宏 (Fatal Error)
// ----------------------------------------------------

/**
 * @brief 致命错误处理宏。用于系统调用失败时立即终止程序。
 * * @param msg 错误信息字符串。
 * * 作用：打印用户提供的错误信息、当前 errno 对应的系统错误描述，以及文件名和行号，然后立即退出进程。
 * 适用于 socket(), bind(), listen(), connect() 等无法恢复的致命错误。
 */
#define handle_error(msg) \
    do { \
        fprintf(stderr, "[FATAL ERROR] %s: %s (File: %s, Line: %d)\n", \
                msg, strerror(errno), __FILE__, __LINE__); \
        exit(EXIT_FAILURE); \
    } while (0)


// 宏定义 2: 检查命令行参数数量
// ----------------------------------------------------

/**
 * @brief 检查命令行参数数量的宏。
 * @param argc main函数的参数计数。
 * @param expected_count 期望的参数总数（程序名 + 参数数量）。
 * @param usage_msg 打印给用户的程序使用说明字符串。
 * * 作用：如果 argc != expected_count，打印错误信息和使用说明，然后退出程序。
 */
#define checkArg(argc, expected_count, usage_msg) \
    do { \
        if ((argc) != (expected_count)) { \
            fprintf(stderr, "[ARGUMENT ERROR] Incorrect number of arguments provided.\n"); \
            fprintf(stderr, "Usage: %s\n", usage_msg); \
            exit(EXIT_FAILURE); \
        } \
    } while (0)




#endif

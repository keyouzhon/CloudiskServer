#include "func.h"
#include "handle.h"
#define out(msg) std::cout<<msg<<std::endl
int main(int argc,char**argv)
{
    checkArg(argc,3,"[arguments number error]:expect 3 arguments->./*.exe ip port."); 
    char*ip=argv[1];
    char*port=argv[2];
    //--->1.create sockets
    int serv_fd;
    if((serv_fd=socket(AF_INET,SOCK_STREAM,0))==0)
    {
        perror("error in creating socket");
        exit(EXIT_FAILURE);
    }

    //--->2.create sockaddr_in struct.
    struct sockaddr_in serv_addr;
    socklen_t serv_len = sizeof(serv_addr);
    serv_addr.sin_family = AF_INET;
    serv_addr.sin_addr.s_addr = inet_addr(ip);
    serv_addr.sin_port=htons(atoi(port));

    //--->3.bind socket with ip and port.
    if(bind(serv_fd,(struct sockaddr*)& serv_addr,serv_len) < 0 )
    {
        perror("error in bind socket with ip and port");
        exit(EXIT_FAILURE);
    }

    //--->4.listen the connection from clients.
    int listenfd;
    if((listen(serv_fd,3)) < 0 )
    {
        perror("error in listening connections");
        exit(EXIT_FAILURE);
    }
    listenfd=serv_fd;
    std::cout<<"waiting for client..."<<std::endl;
    //--->5.accept the connections
    struct sockaddr_in cli_addr;
    socklen_t cli_addr_len = sizeof(cli_addr);
    fd_set allset,rset;//set fd_set
    int con_fd,sockfd;
    int ret,maxfd,maxi,i,j,nready,nByte;
    int client[FD_SETSIZE];
    char buff[bufferSize];
    FD_ZERO(&allset);
    FD_SET(listenfd,&allset);
    out("FD_ZERO(&asllset).");
    maxfd=listenfd;//select()的第一个参数
    maxi = -1;
    char str[INET_ADDRSTRLEN]{0};
    for(i = 0;i < FD_SETSIZE;++i)
    {
        client[i] = -1;
    }
    out("client[i~FD_SETSIZE]=-1");

    while(1)
    {
        rset=allset;
        nready = select(maxfd+1,&rset,NULL,NULL,NULL);
        if(nready < 0)
        {
            perror("select error");
            close(listenfd);
            exit(-1);
        }
        out("select() returns a value:");
        out(nready);
        //全连接队列有客户端请求时
        if(FD_ISSET(listenfd,&rset))
        {
            out("A client is requesting to connect.");
            cli_addr_len=sizeof(cli_addr);

            //con_fd is reusable,has a different value in each loop.
            con_fd=accept(listenfd,(struct sockaddr*) & cli_addr,&cli_addr_len);
            out("accept() returns a value:");
            out(con_fd);
            if(-1==con_fd)
            {
                perror("accept error");
                exit(-1);
            }
            printf("received from %s:%d\n",
                   inet_ntop(AF_INET,&cli_addr.sin_addr,str,sizeof(str)),
                   ntohs(cli_addr.sin_port));


            //更新客户端连接数组
            for(i=0;i<FD_SETSIZE;++i)
            {
                if(client[i] < 0)
                {
                    client[i]=con_fd;
                    break;
                }
            }
            out("Update client array.");
            //超过最大连接数的情况
            if(i==FD_SETSIZE)
            {
                fputs("too many clients\n",stderr);
                exit(1);
            }
                
            //put con_fd in bitMap.
            FD_SET(con_fd,&allset);

            //更新maxfd
            if(con_fd > maxfd)
            {
                maxfd=con_fd;
            }
            //更新maxi
            if(i > maxi)
            {
                maxi=i;
            }
            if(--nready==0)
            {
                //处理完了，提前进入下一次循环
                continue;
            }
        }
        for(i=0;i <= maxi; ++i)
        {
            if((sockfd=client[i]) < 0)
            {
                continue;
            }
            if(FD_ISSET(sockfd,&rset))
            {
                out("A client try to send message.");
                if((nByte = read(sockfd,buff,sizeof(buff)))==0)
                { 
                    close(sockfd);
                    printf("client[sockfd:%d] closed connected\n",sockfd);
                    FD_CLR(sockfd,&allset);
                    client[i]=-1;
                }
                else if(nByte > 0)
                {
                    out("nByte is greater than 0.");
                    for(j=0;j<nByte;++j)
                    {
                        buff[j] = toupper(buff[j]);
                    }
                    write(sockfd,buff,nByte);
                    write(STDOUT_FILENO,buff,nByte);
                    write(STDOUT_FILENO,"\n",2);
                }
                if(--nready==0)
                {
                    break;
                }
            }
        }


    }
    close(serv_fd);
    close(con_fd);
    return 0;
}

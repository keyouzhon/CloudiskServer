#include "func.h"
#include "handle.h"
using std::thread;

int main(int argc,char** argv)
{

    checkArg(argc,3,"[arguments number error]->expect 3 arguments (./*.exe ip port)");
    char * port=argv[2];
    char * ip=argv[1];
    //--->1.create socket.
    int cli_fd;
    if((cli_fd=socket(AF_INET,SOCK_STREAM,0)) < 0)
    {
        std::cerr<<"[error]error in creating socket";
        exit(EXIT_FAILURE);
    }

    //--->2.intiate the request.
    struct sockaddr_in serv_addr{};
    serv_addr.sin_family=AF_INET;

    serv_addr.sin_port=htons(atoi(port));
    serv_addr.sin_addr.s_addr=inet_addr(ip);

    if(connect(cli_fd,(struct sockaddr*)& serv_addr,sizeof(serv_addr)))
    {
        std::cerr<<"[error] error in connect()\n";
        exit(EXIT_FAILURE);
    }
    std::cout<<"connected to the server["<<ip<<":"<<port<<"]"<<std::endl;
    

    //--->3.exchange information
    std::string input{};
    while(1)
    {
        printf("input here:");

        getline(std::cin,input);
        write(cli_fd,input.c_str(),input.size());
    }
    close(cli_fd);
    return 0;
}


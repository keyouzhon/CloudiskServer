#include "func.h"
#include "handle.h"
#define MAX_OPEN 2048
#define out(msg) std::cout<<msg<<std::endl
int main(int argc,char**argv)
{
    checkArg(argc,3,"[arguments number error]:expect 3 arguments->./*.exe ip port."); 
    char*ip=argv[1];
    char*port=argv[2];
    //--->1.create sockets
    int serv_fd;
    if((serv_fd=socket(AF_INET,SOCK_STREAM,0))==0)
    {
        perror("error in creating socket");
        exit(EXIT_FAILURE);
    }

    //--->2.create sockaddr_in struct.
    struct sockaddr_in serv_addr;
    socklen_t serv_len = sizeof(serv_addr);
    serv_addr.sin_family = AF_INET;
    serv_addr.sin_addr.s_addr = inet_addr(ip);
    serv_addr.sin_port=htons(atoi(port));

    //--->3.bind socket with ip and port.
    if(bind(serv_fd,(struct sockaddr*)& serv_addr,serv_len) < 0 )
    {
        perror("error in bind socket with ip and port");
        exit(EXIT_FAILURE);
    }

    //--->4.listen the connection from clients.
    int listenfd;
    if((listen(serv_fd,3)) < 0 )
    {
        perror("error in listening connections");
        exit(EXIT_FAILURE);
    }
    listenfd=serv_fd;
    std::cout<<"waiting for client..."<<std::endl;
    //--->5.accept the connections
    struct sockaddr_in cli_addr;
    socklen_t cli_addr_len = sizeof(cli_addr);
    int con_fd;

    int epfd=epoll_create(MAX_OPEN);
    struct epoll_event ev, client_events[MAX_OPEN];
    int nReady,nByte,i,j;
    int current_fd;
    ev.data.fd=listenfd;
    ev.events=EPOLLIN;
    epoll_ctl(epfd,EPOLL_CTL_ADD,listenfd,&ev);

    char buff[bufferSize];
    char str[INET_ADDRSTRLEN]{0};

    while(1)
    {

        nReady = epoll_wait(epfd,client_events,MAX_OPEN,-1);
        if(nReady < 0)
        {
            perror("poll error.");
            close(listenfd);
            exit(-1);
        }
        //全连接队列有客户端请求时
        for(i=0;i<nReady;++i)
        {
            current_fd=client_events[i].data.fd;    

            if(current_fd==listenfd)
            {
                cli_addr_len=sizeof(cli_addr);

                //con_fd is reusable,has a different value in each loop.
                con_fd=accept(listenfd,(struct sockaddr*) & cli_addr,&cli_addr_len);
                if(-1==con_fd)
                {
                    perror("accept error");
                    exit(-1);
                }
                printf("received from %s:%d\n",
                       inet_ntop(AF_INET,&cli_addr.sin_addr,str,sizeof(str)),
                       ntohs(cli_addr.sin_port));

                ev.events=POLLIN;
                ev.data.fd=con_fd;
                epoll_ctl(epfd,EPOLL_CTL_ADD,con_fd,&ev);


                //超过最大连接数的情况
                if(i==MAX_OPEN)
                {
                    fputs("too many clients\n",stderr);
                    exit(1);
                }


            }
            else
            {
                if((nByte = read(current_fd,buff,sizeof(buff)))==0)
                { 
                    close(current_fd);
                    printf("client[sockfd:%d] closed connected\n",current_fd);
                    epoll_ctl(epfd,EPOLL_CTL_DEL,current_fd,NULL);
                }
                else if(nByte > 0)
                {
                    for(j=0;j<nByte;++j)
                    {
                        buff[j] = toupper(buff[j]);
                    }
                    write(current_fd,buff,nByte);
                    write(STDOUT_FILENO,buff,nByte);
                    write(STDOUT_FILENO,"\n",2);
                }

            }


        }
    }
    close(serv_fd);
    close(con_fd);
    return 0;
}

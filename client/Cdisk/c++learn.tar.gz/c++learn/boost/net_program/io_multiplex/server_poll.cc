#include "func.h"
#include "handle.h"
#define MAX_OPEN 2048
#define out(msg) std::cout<<msg<<std::endl
int main(int argc,char**argv)
{
    checkArg(argc,3,"[arguments number error]:expect 3 arguments->./*.exe ip port."); 
    char*ip=argv[1];
    char*port=argv[2];
    //--->1.create sockets
    int serv_fd;
    if((serv_fd=socket(AF_INET,SOCK_STREAM,0))==0)
    {
        perror("error in creating socket");
        exit(EXIT_FAILURE);
    }

    //--->2.create sockaddr_in struct.
    struct sockaddr_in serv_addr;
    socklen_t serv_len = sizeof(serv_addr);
    serv_addr.sin_family = AF_INET;
    serv_addr.sin_addr.s_addr = inet_addr(ip);
    serv_addr.sin_port=htons(atoi(port));

    //--->3.bind socket with ip and port.
    if(bind(serv_fd,(struct sockaddr*)& serv_addr,serv_len) < 0 )
    {
        perror("error in bind socket with ip and port");
        exit(EXIT_FAILURE);
    }

    //--->4.listen the connection from clients.
    int listenfd;
    if((listen(serv_fd,3)) < 0 )
    {
        perror("error in listening connections");
        exit(EXIT_FAILURE);
    }
    listenfd=serv_fd;
    std::cout<<"waiting for client..."<<std::endl;
    //--->5.accept the connections
    struct sockaddr_in cli_addr;
    socklen_t cli_addr_len = sizeof(cli_addr);
    int con_fd,sockfd;
    struct pollfd client[MAX_OPEN];
    int nReady,nByte,i,j,maxi=0;

    client[0].fd=listenfd;
    client[0].events=POLLIN;


    for(int i=1;i<MAX_OPEN;++i)
        client[i].fd=-1;


    char buff[bufferSize];
    char str[INET_ADDRSTRLEN]{0};

    while(1)
    {

        nReady = poll(client,maxi+1,-1);
        if(nReady < 0)
        {
            perror("poll error.");
            close(listenfd);
            exit(-1);
        }
        //全连接队列有客户端请求时
        if(client[0].revents & POLLIN)
        {
            cli_addr_len=sizeof(cli_addr);

            //con_fd is reusable,has a different value in each loop.
            con_fd=accept(listenfd,(struct sockaddr*) & cli_addr,&cli_addr_len);
            if(-1==con_fd)
            {
                perror("accept error");
                exit(-1);
            }
            printf("received from %s:%d\n",
                   inet_ntop(AF_INET,&cli_addr.sin_addr,str,sizeof(str)),
                   ntohs(cli_addr.sin_port));


            //更新客户端连接数组
            for(i=0;i<MAX_OPEN;++i)
            {
                if(client[i].fd == -1)
                {
                    client[i].fd=con_fd;
                    maxi= maxi > i ? maxi : i;
                    break;
                }
            }
            client[0].events=POLLIN;
            //超过最大连接数的情况
            if(i==FD_SETSIZE)
            {
                fputs("too many clients\n",stderr);
                exit(1);
            }


            if(--nReady==0)
            {
                //处理完了，提前进入下一次循环
                continue;
            }
        }
        for(i=1;i <= maxi; ++i)
        {
            if((sockfd=client[i].fd) < 0)
            {
                continue;
            }
            if(client[i].revents & POLLIN)
            {
                if((nByte = read(sockfd,buff,sizeof(buff)))==0)
                { 
                    close(sockfd);
                    printf("client[sockfd:%d] closed connected\n",sockfd);
                    client[i].fd=-1;
                }
                else if(nByte > 0)
                {
                    for(j=0;j<nByte;++j)
                    {
                        buff[j] = toupper(buff[j]);
                    }
                    write(sockfd,buff,nByte);
                    write(STDOUT_FILENO,buff,nByte);
                    write(STDOUT_FILENO,"\n",2);
                }
                if(--nReady==0)
                {
                    break;
                }
            }
        }


    }
    close(serv_fd);
    close(con_fd);
    return 0;
}

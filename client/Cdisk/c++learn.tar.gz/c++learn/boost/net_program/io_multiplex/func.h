#ifndef __func_H__
#define __func_H__
#include <iostream>   // C++ 标准库：用于输入输出流，如 std::cout, std::cerr
#include <cstdlib>    // C 标准库：用于 EXIT_SUCCESS, EXIT_FAILURE 和通用工具
#include <cstring>    // C 字符串操作：用于 memset, strerror 等内存和字符串函数

// --- POSIX/System Headers for Sockets ---
#include <unistd.h>     // POSIX 系统调用：提供 close(), read(), write() 等
#include <sys/types.h>  // 系统基本类型定义：定义了 size_t, time_t 等类型
#include <sys/socket.h> // 套接字核心定义：提供 socket(), bind(), listen(), accept() 等函数和类型
#include <netinet/in.h> // Internet 地址族定义：提供 sockaddr_in 结构体和协议常量 AF_INET, IPPROTO_TCP
#include <arpa/inet.h>  // IP 地址转换：提供 inet_addr(), inet_ntoa() 等函数
#include <sys/select.h>
#include <sys/epoll.h>
#include <sys/poll.h>
// --- 线程或并发模型所需 (如果是非单线程服务器) ---
#include <thread>       // C++11 标准库：用于创建和管理线程 (如果使用多线程模型)
#include <pthread.h>    // POSIX 线程库：用于 pthreads API (如果使用 pthreads 模型)
#include <string>
#include <vector>

#define bufferSize 1024



#endif

//server.cc
#include<iostream>
#include<sys/socket.h>
#include<netinet/in.h>
#include<unistd.h>
#include<cstring>
#include<string>
#include<arpa/inet.h>
#define bufferSize 1024
bool checkArg(int);
int main(int argc,char**argv)
{
    std::string port{0};
    std::string ip{0};
    if(!checkArg(argc))
    {
        std::cin>>ip>>port;
    }
    else
    {
        port = argv[2];
        ip = argv[1];
    }//check args and transfer to string.
    //--->1.create sockets
    int serv_fd,con_fd;
    if((serv_fd=socket(AF_INET,SOCK_STREAM,0))==0)
    {
        perror("error in creating socket");
        exit(EXIT_FAILURE);
    }

    //--->2.create sockaddr_in struct.
    struct sockaddr_in serv_addr;
    socklen_t serv_len = sizeof(serv_addr);
    serv_addr.sin_family = AF_INET;
    serv_addr.sin_addr.s_addr = inet_addr(ip.data());
    serv_addr.sin_port=htons(atoi(port.data()));

    //--->3.bind socket with ip and port.
    if(bind(serv_fd,(struct sockaddr*)& serv_addr,serv_len) < 0 )
    {
        perror("error in bind socket with ip and port");
        exit(EXIT_FAILURE);
    }

    //--->4.listen the connection from clients.
    if(listen(serv_fd,3) < 0 )
    {
        perror("error in listening connections");
        exit(EXIT_FAILURE);
    }
    std::cout<<"waiting for client..."<<std::endl;
    //--->5.accept the connections
    struct sockaddr_in cli_addr;
    socklen_t cli_len = sizeof(cli_addr);
    if((con_fd=accept(serv_fd,(struct sockaddr*)& cli_addr,&cli_len)) < 0 )
    {
        perror("error in accepting the connections");
        exit(EXIT_FAILURE);
    }

    //--->6.exchange information with client side.
    int len;
    while(1)
    {
        char buff[bufferSize]{0};
        len = recv(con_fd,buff,sizeof(buff),0);
        if(len < 0)
        {
            perror("failed to receive message from client");
            exit(EXIT_FAILURE);
        }
        std::cout<<"received message[len:"<<len<<"]from"<<inet_ntoa(cli_addr.sin_addr)<<":"
            <<ntohs(cli_addr.sin_port)<<"-->"<<buff<<std::endl;
        std::cout<<"sending message to client."<<std::endl;
        std::cout<<"input here:";
        std::string line{0};
        getline(std::cin,line);
        len=send(con_fd,line.data(),line.size(),0);
        std::cout<<"sended a message["<<len<<"]"<<std::endl;
    }
    close(serv_fd);
    close(con_fd);
    return 0;
}
bool checkArg(int argc)
{
    if(argc!=3)
    {
        perror("input again(ip and port):");
        return 0;
    }
    else
    {
        return 1;
    }
}

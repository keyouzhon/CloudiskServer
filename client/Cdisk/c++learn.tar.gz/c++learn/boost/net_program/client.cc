//client.cc
#include<iostream>
#include<arpa/inet.h>
#include<sys/socket.h>
#include<netinet/in.h>
#include<unistd.h>
#include<cstring>
#include<string>
#include<cstdlib>
using std::string;
#define buffSize 1024
bool checkArg(int);
int main(int argc,char** argv)
{
    string ip{0};
    string port{0};
    if(!checkArg(argc))
    {
        std::cin>>ip>>port;
    }
    else
    {
        ip=argv[1];
        port=argv[2];
    }
    //--->1.create socket.
    int cli_fd;
    if((cli_fd=socket(AF_INET,SOCK_STREAM,0)) < 0)
    {
        std::cerr<<"[error]error in creating socket";
        exit(EXIT_FAILURE);
    }

    //--->2.intiate the request.
    struct sockaddr_in serv_addr{};
    serv_addr.sin_family=AF_INET;

    serv_addr.sin_port=htons(atoi(port.c_str()));
    serv_addr.sin_addr.s_addr=inet_addr(ip.c_str());

    if(connect(cli_fd,(struct sockaddr*)& serv_addr,sizeof(serv_addr)))
    {
        std::cerr<<"[error] error in connect()";
        exit(EXIT_FAILURE);
    }

    if(std::cin.peek()=='\n')
    {
        std::cin.ignore();
    }//取走换行符

    std::cout<<"connected to the server["<<ip<<":"<<port<<"]"<<std::endl;
    //--->3.exchange information
    while(1)
    {
        std::cout<<"input here:";
        string line{0};
        getline(std::cin,line);
        if(send(cli_fd,line.data(),line.size(),0) < 0)
        {
            std::cerr<<"[error] error in send()";
            exit(EXIT_FAILURE);
        }
        std::cout<<"sended the message."<<std::endl;

        char buff[buffSize]{0};
        if(recv(cli_fd,buff,sizeof(buff),0) < 0)
        {
            std::cerr<<"[error] erro in recv()";
            exit(EXIT_FAILURE);
        }
        std::cout<<"received a message from server."<<"--->:"<<buff<<std::endl;
    }
    return 0;
}
bool checkArg(int argc)
{
    if(argc!=3)
    {
        std::cerr<<"please input ip and port:";
        return 0;
    }
    return 1;
}

#include <iostream>
#include <thread>
#include <mutex>

// 定义一个全局或共享的互斥锁
std::mutex cout_mutex; 

void print_message(int id) {
    // 互斥锁必须包裹住整个逻辑序列
    std::lock_guard<std::mutex> lock(cout_mutex); 
    
    // 这是临界区：只有持有锁的线程才能执行这段代码
    std::cout << "Thread " << id 
              << ": This is an ATOMIC and complete message." 
              << std::endl; 
    
    // lock_guard 在作用域结束时自动释放锁
}

int main() {
    std::thread t1(print_message, 1);
    std::thread t2(print_message, 2);
    
    t1.join();
    t2.join();
    
    // 输出结果将是两行完整、顺序清晰的句子，不会相互交错。
    return 0;
}

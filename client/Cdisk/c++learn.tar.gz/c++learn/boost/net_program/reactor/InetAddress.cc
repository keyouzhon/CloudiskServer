#include "InetAddress.h"
#include <arpa/inet.h>
inetAddress::inetAddress(const string & ip,unsigned short port)
{
    ::bzero(&_addr,sizeof(_addr));
    _addr.sin_family = AF_INET;
    inet_aton(ip.data(),&(_addr.sin_addr));
    _addr.sin_port=htons(port);
}
inetAddress::~inetAddress()
{

};
string inetAddress::ip() const
{
    static char ip_buffer[INET_ADDRSTRLEN];
    inet_ntop(AF_INET,&(_addr.sin_addr),ip_buffer,INET_ADDRSTRLEN);
    return string(ip_buffer);
    //return string(inet_aton(_Addr.sin_addr));
};
unsigned short inetAddress::port() const
{
    return ntohs(_addr.sin_port);
};
const struct sockaddr * inetAddress::getInetAddressPtr() const
{
    return (struct sockaddr *) & (_addr);
};
//初始化列表中只能初始化类的直接成员，而不是_addr.sin_port;
/* inetAddress::inetAddress(const struct sockaddr_in & addr) */
/*     :_addr.sin_port(addr.sin_port), */
/*      _addr.sin_addr.s_addr(addr.sin_addr.s_addr) */
/* { */

/* }; */
inetAddress::inetAddress(const struct sockaddr_in & addr)
    :_addr(addr)
{

}

#include "EventLoop.h"
#include <unistd.h>
#include <errno.h>
#include <error.h>
#include <iostream>

eventLoop::eventLoop(const acceptor & acc)
    :_epfd(createEpollFd())
    ,_evList(1024)
    ,_isLooping(false)
    ,_acceptor(acc)
{

    //将listenfd放在红黑树上监听
    int listenfd=_acceptor.fd(); 
    addEpollReadFd(listenfd);
}
eventLoop::~eventLoop()
{
    close(_epfd);
}
void eventLoop::loop()
{
    _isLooping = true;
    while(_isLooping)
    {
        waitEpollFd();
    }
}
void eventLoop::unLoop()
{
    _isLooping = false;
}
int eventLoop::createEpollFd()
{
    int fd;
    if((fd = ::epoll_create(1)) < 0)
    {
        perror("creadeEpoll");
        exit(-1);
    }
    return fd;
}
void eventLoop::addEpollReadFd(int fd)
{
    struct epoll_event ev;
    ev.events=EPOLLIN;
    ev.data.fd=fd;
    int ret = ::epoll_ctl(_epfd,EPOLL_CTL_ADD,fd,&ev);
    if(ret < 0)
    {
        perror("addEpollReadFd");
        exit(-1);
    }
}
void eventLoop::waitEpollFd()
{
    int nready = 0;
    do
    {
        nready = ::epoll_wait(_epfd,&_evList[0],_evList.size(),3000);
    }while(-1 == nready && errno == EINTR);

    if(-1 == nready)
    {
        std::cerr<<"-1 == nready"<<std::endl;
    }
    else if(0 == nready)
    {
        std::cout<<"[][]epoll_wait timeout!!!!!"<<std::endl;
    }
    else
    {
        //当客户端达到上限1024时，扩容
        nready==(int)_evList.size() ? _evList.resize(2*nready) : void();
        for(int idx=0;idx<nready;++idx)
        {
            int fd = _evList[idx].data.fd;
            int listenfd = _acceptor.fd();
            if(listenfd == fd)
            {
                handleNewConnection();
            }
            else
            {
                handleMessage(fd);
            }
        }
    }
}
void eventLoop::handleNewConnection()
{
    int connfd = _acceptor.accept();
    if(connfd < 0)
    {
        perror("handleNewConnection");
        return;
    }
    //将connfd放在红黑树上监听
    addEpollReadFd(connfd);
    //三次握手成功，创建tcpConnection
    tcpConnectionPtr con{new tcpConnection(connfd)};
    _conns[connfd]=con;

}
void eventLoop::handleMessage(int fd)
{
    auto it = _conns.find(fd);
    if(it != _conns.end())
    {
        string msg=it->second->receive();
        std::cout<<"received msg:"<<msg<<std::endl;

        //业务逻辑
        it->second->send(msg);
        if(msg.empty())
            delEpollReadFd(fd);
    }
    else
    {
        std::cout<<"no connection[fd:"<<fd<<"]"<<std::endl;
    }
}
void eventLoop::delEpollReadFd(int fd)
{
    struct epoll_event ev;
    ev.events=EPOLLIN;
    ev.data.fd=fd;
    int ret = ::epoll_ctl(_epfd,EPOLL_CTL_DEL,fd,&ev);
    if(ret < 0)
    {
        perror("delEpollReadFd");
        exit(-1);
    }
}

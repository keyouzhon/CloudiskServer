#ifndef __TcpConnection_H__
#define __TcpConnection_H__

#include "Socket.h"
#include "SocketIO.h"
#include "InetAddress.h"
#include <sys/socket.h>

class tcpConnection
{
private:
    socketIO _sockIO;
public:
    explicit tcpConnection(int fd);
    ~tcpConnection();

    string receive();
    void send(const string & msg);
    //调试用
    string toString();
private:
    inetAddress getLocalAddr();
    inetAddress getPeerAddr();
private:
    //调试用
    class socket _sock;
    inetAddress _localAddr;
    inetAddress _peerAddr;
}
;




#endif

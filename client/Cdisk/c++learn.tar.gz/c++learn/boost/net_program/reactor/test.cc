#include "Socket.h"
#include "InetAddress.h"
#include "TcpConnection.h"
#include "Acceptor.h"
#include <iostream>
#include "EventLoop.h"

int main()
{
    acceptor ac("127.0.0.1",8888);
    ac.ready();
    eventLoop loop(ac);
    loop.loop();
    return 0;
}

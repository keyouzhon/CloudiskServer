#ifndef __EventLoop_H__
#define __EventLoop_H__
#include <vector>
#include <map>
#include <memory>
#include <sys/epoll.h>
#include "Acceptor.h"
#include "Socket.h"
#include "InetAddress.h"
#include "TcpConnection.h"
using std::vector;
using std::map;
using std::shared_ptr;
using tcpConnectionPtr = shared_ptr<tcpConnection>;
class eventLoop
{
private:
    int _epfd;//由epoll_creat()创建的文件描述符
    vector<struct epoll_event> _evList;//交给epoll_wait()的第二个参数，存放就绪的文件描述符
    bool _isLooping;//是否进入循环的标识
    acceptor _acceptor;
    map<int,tcpConnectionPtr> _conns;//存放fd,tcpConnection连接的键值对
public:
    eventLoop(const acceptor & acc);
    ~eventLoop();
    //是否在循环
    void loop();
    void unLoop();

    //封装epoll_creat()
    int createEpollFd();

    //将文件描述符放在红黑树上进行监听
    void addEpollReadFd(int fd);
    
    //封装epoll_wait()
    void waitEpollFd();
    
    //处理新的客户端连接
    void handleNewConnection();
    
    //处理旧的连接
    void handleMessage(int fd);

    //从红黑树上摘除
    void delEpollReadFd(int fd);
}
;
#endif

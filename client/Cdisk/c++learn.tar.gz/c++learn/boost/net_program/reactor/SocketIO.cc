#include "SocketIO.h"
#include "SocketIO.h"
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/socket.h>

socketIO::socketIO(int fd)
    :_fd(fd)
{

}
socketIO::~socketIO()
{

}
int socketIO::readn(char * buf,int len)
{
    int left = len;
    char *pstr = buf;
    int ret = 0;
    while(left > 0)
    {
        ret = read(_fd,pstr,left);
        if(-1==ret && errno == EINTR)
        {
            continue;
        }
        else if(-1==ret)
        {
            perror("socketIO::readn");
            break;
        }
        else if(0==ret)
        {
            perror("socketIO::readn");
            break;
        }
        else
        {
            pstr += ret;
            left -= ret;
        }
    }
    return len-left;
}
int socketIO::readLine(char * buf,int len)
{
    int left = len - 1;
    char * pstr = buf;
    int ret = 0,total = 0;

    while(left > 0)
    {
        ret = recv(_fd,pstr,left,MSG_PEEK);
        if(-1 == ret && errno == EINTR)
        {
            continue;
        }
        else if(-1 == ret)
        {
            perror("socketIO::readLine()");
            break;
        }
        else if(0 == ret)
        {
            perror("socketIO::readLine()");
            break;
        }
        else
        {
            for(int idx=0;idx < ret;++idx)
            {
                if(pstr[idx] == '\n')
                {
                    int sz = idx+1;
                    readn(pstr,sz);
                    pstr+=sz;
                    *pstr = '\0';

                    return total + sz;
                }
            }
            readn(pstr,ret);
            total += ret;
            pstr += ret;
            left -= ret;
        }

    }
    *pstr = '\0';//保险起见，以防用来接收的缓冲区没0初始化，或者存满了（这个时候会out of range？？）。
    return total-left;
}
int socketIO::writen(const char * buf,int len)
{
    int left = len;
    const char *pstr = buf;
    int ret = 0;
    while(left > 0)
    {
        ret = write(_fd,pstr,left);
        if(-1==ret && errno == EINTR)
        {
            continue;
        }
        else if(-1==ret)
        {
            perror("socketIO::writen");
            break;
        }
        else if(0==ret)
        {
            perror("socketIO::writen");
            break;
        }
        else
        {
            pstr += ret;
            left -= ret;
        }
    }
    return len-left;

}

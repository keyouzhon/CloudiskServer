#include "TcpConnection.h"
#include <sstream>
tcpConnection::tcpConnection(int fd)
    :_sockIO(fd),
     _sock(fd),
     _localAddr(getLocalAddr()),
     _peerAddr(getPeerAddr())
{

}

tcpConnection::~tcpConnection()
{

}

string tcpConnection::receive()
{
    char buff[65535] = {0};
    _sockIO.readLine(buff,sizeof(buff));

    return string(buff);
}
void tcpConnection::send(const string & msg)
{
    _sockIO.writen(msg.c_str(),msg.size());
}
string tcpConnection::toString()
{
    std::ostringstream oss;
    oss <<_localAddr.ip() << ":"
        <<_localAddr.port()<< "---->"
        <<_peerAddr.ip() <<  ":"
        <<_peerAddr.port();
    return oss.str();
}
inetAddress  tcpConnection::getLocalAddr()
{
    struct sockaddr_in addr;
    socklen_t len = sizeof(addr);
    int ret = getsockname(_sock.getFd(),(struct sockaddr*) & addr,&len);
    if(ret == -1)
    {
        perror("getsockname");
    }
    return inetAddress(addr);
}
inetAddress tcpConnection::getPeerAddr()
{
    struct sockaddr_in addr;
    socklen_t len = sizeof(addr);
    int ret = getpeername(_sock.getFd(),(struct sockaddr*) & addr,&len);
    if(ret == -1)
    {
        perror("getpeername");
    }
    return inetAddress(addr);
}

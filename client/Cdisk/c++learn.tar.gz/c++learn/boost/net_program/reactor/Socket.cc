#include "Socket.h"
#include <sys/types.h>
#include <sys/socket.h>
#include <unistd.h>
#include <stdio.h>
int fdGet()
{
    return ::socket(AF_INET,SOCK_STREAM,0);
}
socket::socket()
    :_fd(fdGet())
{
    if(_fd < 0)
    {
        perror("socket()");
        return;
    }

}
socket::socket(int fd)
    :_fd(fd)
{

}
//const 没用，返回的本身就是拷贝的_fd
const int socket::getFd()
{
    return _fd;
}
socket::~socket()
{
    close(_fd);
}


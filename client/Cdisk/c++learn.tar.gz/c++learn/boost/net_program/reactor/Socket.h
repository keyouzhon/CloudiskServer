#ifndef __socket_H__
#define __socket_H__
#include "nonCopyable.h"
class socket
//:nonCopyable
{
private:
    int _fd;
public:
    socket();
    explicit socket(int fd);
    ~socket();
    //const 无用
    const int getFd();
}
;




#endif

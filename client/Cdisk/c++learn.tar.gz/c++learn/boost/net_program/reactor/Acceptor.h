#ifndef __Acceptor_H__
#define __Acceptor_H__
#include <sys/socket.h>
#include "Socket.h"
#include "InetAddress.h"
#include <string>
class acceptor
{
private:
    class socket _sock;
    class inetAddress _addr;
public:
    acceptor(const string & ip,unsigned short port);
    ~acceptor();
    void ready();//外部调用私有函数的接口
    int accept();
    int fd();
private:
    void setReuseAddr();
    void setReusePort();
    void bind();
    void listen();
}
;



#endif

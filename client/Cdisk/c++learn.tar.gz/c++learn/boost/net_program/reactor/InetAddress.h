#ifndef __InetAddress_H__
#define __InetAddress_H__
#include <sys/socket.h>
#include <netinet/in.h>
#include <string>
#include <string.h>
using std::string;
class inetAddress
{
private:
    struct sockaddr_in _addr;
public:
    inetAddress(const string & ip,unsigned short port);
    inetAddress(const struct sockaddr_in & addr);
    ~inetAddress();
    string ip() const;
    unsigned short port() const;
    const struct sockaddr * getInetAddressPtr() const;
};





#endif

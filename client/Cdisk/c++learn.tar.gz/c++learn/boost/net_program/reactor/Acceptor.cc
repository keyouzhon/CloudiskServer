#include "Acceptor.h"
acceptor::acceptor(const string & ip,unsigned short port)
    :_sock(),
     _addr(ip,port)
{

}
acceptor::~acceptor()
{

}
void acceptor::ready()//外部调用私有函数的接口
{

    setReuseAddr();
    setReusePort();
    bind();
    listen();
}
int acceptor::accept()
{
    int connfd = ::accept(_sock.getFd(),nullptr,nullptr);
    if(-1==connfd)
    {
        perror("accept");
        exit(-1);
    }
}
void acceptor::setReuseAddr()
{
    int on = 1;
    int ret = setsockopt(_sock.getFd(),SOL_SOCKET,SO_REUSEADDR,&on,sizeof(on));
    if(ret)
    {
        perror("setsockopt");
        exit(-1);
    }
};
void acceptor::setReusePort()
{
    int on =1;
    int ret =setsockopt(_sock.getFd(),SOL_SOCKET,SO_REUSEPORT,&on,sizeof(on));
    if(-1==ret)
    {
        perror("setsockopt");
        exit(-1);
    }
}
void acceptor::bind()
{
    int ret = ::bind(_sock.getFd(),_addr.getInetAddressPtr(),sizeof(struct sockaddr));
    if(-1 == ret)
    {
        perror("bind");
        exit(-1);
    }
}
void acceptor::listen()
{
    int ret = ::listen(_sock.getFd(),128);
    if(-1==ret)
    {
        perror("listen");
        exit(-1);
    }
}
int acceptor::fd()
{
    return _sock.getFd();
}

#ifndef __SocketIO_H__
#define __SocketIO_H__
class socketIO
{
private:
    int _fd;
public:
    explicit socketIO(int fd);
    ~socketIO();
    int readn(char * buf,int len);
    int readLine(char * buf,int len);
    int writen(const char * buf,int len);
}
;




#endif

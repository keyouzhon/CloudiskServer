#include <unistd.h> // For write(), read(), sleep()
#include <cstring>  // For strlen()

int main() {
    // Step 1: Write the prompt directly to stdout (file descriptor 1)
    const char* prompt = "I will wait 3 seconds BEFORE asking for input. You should see me now.\n";
    write(1, prompt, strlen(prompt));

    // Step 2: Introduce a long, undeniable delay.
    // During these 3 seconds, the program is doing NOTHING but sleeping.
    // It is NOT waiting for input yet.
    sleep(3);

    // Step 3: Now, AFTER the sleep, ask for input.
    const char* ask_input = "Now, please enter a line: ";
    write(1, ask_input, strlen(ask_input));
    
    char buffer[128];
    read(0, buffer, sizeof(buffer)); // Read from stdin (file descriptor 0)

    // Step 4: Confirm what was read.
    const char* confirmation = "\nThank you.\n";
    write(1, confirmation, strlen(confirmation));

    return 0;
}

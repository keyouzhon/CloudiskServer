// test_io.cc
#include <iostream>
#include <string>
#include <cstdio> // For printf, fflush

int main() {
    std::cout << "--- C++ iostream test ---" << std::endl;
    std::cout << "Enter a line: " << std::flush;
    
    std::string line1;
    std::getline(std::cin, line1);
    std::cout << "You entered: " << line1 << std::endl << std::endl;

    std::cout << "--- C stdio test ---" << std::endl;
    printf("Enter another line: ");
    fflush(stdout);

    std::string line2;
    std::getline(std::cin, line2);
    std::cout << "You entered: " << line2 << std::endl;
    
    return 0;
}

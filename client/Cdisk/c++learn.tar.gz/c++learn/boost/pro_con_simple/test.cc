#include "producer.h"
#include "consumer.h"
#include<thread>
int main()
{
    taskQue<int> sharedque{5};
    producer<int> pro;
    consumer<int> con;

    std::thread pt(&producer<int>::produce,&pro,std::ref(sharedque));
    std::thread ct(&consumer<int>::consume,&con,std::ref(sharedque));

    pt.join();
    ct.join();
    return 0;

}

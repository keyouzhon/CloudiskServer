#include<random>
#include<iostream>
template<class T>
void producer<T>::produce(taskQue<T> & taskque)
{
    int cnt =21;
    while(--cnt)
    {
        std::random_device rd;
        std::mt19937 gen(rd());
        std::uniform_int_distribution<> distrib(1,100);
        int random_number = distrib(gen);
        taskque.push(random_number);
        std::cout<<"[put] produce "<<random_number<<" in taskQue\n";
    }
}

#include<iostream>
template<class T>
void consumer<T>::consume(taskQue<T> & taskque)
{
    int cnt=21;
    while(--cnt)
    {
        T temp{taskque.pop()};
        std::cout<<"[take] consume "<<temp<<" from taskque\n";
    }
}

template<class T>
taskQue<T>::taskQue(size_t capa)
:_capacity(capa)
{}
template<class T>
bool taskQue<T>::isFull()
{
    return _que.size()==_capacity;
}
template<class T>
bool taskQue<T>::isEmpty()
{
    return _que.size()==0;
}
template<class T>
void taskQue<T>::push(T value)
{
    unique_lock<mutex> ul(_mutex);
    while(isFull())
    {
        _notFull.wait(ul);
    }
    _que.push(value);
    _notEmpty.notify_one();
}
template<class T>
T taskQue<T>::pop()
{
    unique_lock<mutex> ul(_mutex);
    while(isEmpty())
    {
        _notEmpty.wait(ul);
    }
    T temp{_que.front()};
    _que.pop();
    _notFull.notify_one();
    return std::move(temp);
}

#ifndef __taskQue_H__
#define __taskQue_H__
#include<mutex>
#include<queue>
#include<condition_variable>
#include<functional>
using std::mutex;
using std::queue;
using std::condition_variable;
using std::unique_lock;
template<class T>
class taskQue
{
//data members
private:
    queue<T> _que;
    size_t _capacity;
    mutex _mutex;
    condition_variable _notFull;
    condition_variable _notEmpty;
//private function
private:
    bool isFull();
    bool isEmpty();
//public function
public:
    taskQue(size_t capa);
    void push(T value);
    T pop();
};

#include "taskQue.hpp"
#endif

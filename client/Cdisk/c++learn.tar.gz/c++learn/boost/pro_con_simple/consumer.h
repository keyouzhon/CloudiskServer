#ifndef __consumer_H__
#define __consumer_H__
#include "taskQue.h"
template<class T>
class consumer
{
    //data menmber, none
    //public function
public:
    void consume(taskQue<T> & taskque);
};
#include "consumer.hpp"
#endif

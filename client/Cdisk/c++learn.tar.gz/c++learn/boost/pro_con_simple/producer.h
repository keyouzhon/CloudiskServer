#ifndef __producer_H__
#define __producer_H__
#include "taskQue.h"
template<class T>
class producer
{
    //data member,none
    //public function
public:
    void produce(taskQue<T> & taskque);
};

#include "producer.hpp"
#endif

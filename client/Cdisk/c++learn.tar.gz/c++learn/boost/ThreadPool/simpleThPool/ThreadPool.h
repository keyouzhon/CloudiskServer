#ifndef __ThreadPool_H__
#define __ThreadPool_H__
#include<vector>
#include<thread>

#include "Task.h"
#include "TaskQueue.h"

using std::vector;
using std::thread;
class ThreadPool
{
public:
    using TaskType=Task *;
    //data member
private:
    size_t _threadNum;
    vector<thread> _threads;//线程池
    size_t _queSize;
    TaskQue<TaskType> _taskQue;//任务队列
    bool _isExit;
    //public function
public:
    ThreadPool(size_t threadNum,size_t queSize);
    ~ThreadPool();
    //线程池启动与停止
    void start();
    void stop();

    //添加任务与分配任务
    void addTask(TaskType ptask);
    TaskType getTask();

    //线程池交给工作线程执行的任务
    void doTask();
};
#endif

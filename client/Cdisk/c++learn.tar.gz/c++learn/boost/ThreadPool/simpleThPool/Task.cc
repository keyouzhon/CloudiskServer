#include "Task.h"
Task::Task()
{

}
Task::~Task()
{

}
void Task::process()
{

}

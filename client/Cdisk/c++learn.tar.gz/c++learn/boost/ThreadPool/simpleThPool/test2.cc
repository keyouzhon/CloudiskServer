#include "Task.h"
#include "TaskQueue.h"
#include "ThreadPool.h"
#include<chrono>
#include<random>
#include<iostream>
#include<memory>
#include<mutex>
#include<atomic>
#include<string>
#include<vector>
using std::unique_ptr;
using std::vector;
std::mutex mu;
std::atomic<int> times{0};

class MyTask
:public Task
{
public:
    void process() override
    {
        ::srand(::clock());
        mu.lock();
        std::cout<<"doing something"<<"["<<::rand()%80<<"]";
        std::this_thread::sleep_for(std::chrono::milliseconds(1));
        std::cout<<"   --->done"<<std::endl;
        mu.unlock();
        std::this_thread::sleep_for(std::chrono::milliseconds(1));
        times++;
    }
};
int main(int argc,char**argv)
{
    if(argc!=2)
    {
        return 1;
    }
    ThreadPool pool(5,10);
    pool.start();
    size_t cnt = std::stoi(argv[1]);
    /* unique_ptr<Task> mt{new MyTask()}; */
    /* thread add([cnt,&pool,&mt]() mutable */
    /*            { */
    /*                 while(--cnt) */
    /*                 { */
    /*                     pool.addTask(mt.get()); */
    /*                 } */
    /*                 std::this_thread::sleep_for(std::chrono::milliseconds(200)); */
    /*            }); */
    /* add.join(); */
    /* pool.stop(); */
    vector<unique_ptr<Task>> mt;
    mt.reserve(10);
    for(int i=0;i<cnt;i++)
    {
        mt.push_back(std::make_unique<MyTask>());
    }
    int i=0;
    while(--cnt)
    {
        pool.addTask(mt[i++].get());
        /* std::this_thread::sleep_for(std::chrono::milliseconds(200)); */
    }
    pool.stop();
    std::cout<<"[][][][][][][->]"<<"times : "<<times<<"\n";
    return 0;
}

template<class T>
TaskQue<T>::TaskQue(size_t capa)
:_capacity(capa),_isExit(false)
{}
template<class T>
bool TaskQue<T>::isFull()
{
    return _que.size()==_capacity;
}
template<class T>
bool TaskQue<T>::isEmpty()
{
    return _que.size()==0;
}
#include<iostream>
template<class T>
void TaskQue<T>::push(T value)
{
    unique_lock<mutex> ul(_mutex);
    while(isFull())
    {
        _notFull.wait(ul);
    }
    _que.push(value);
    std::cout<<"[put] TaskQue<T>::push()"<<std::endl;
    _notEmpty.notify_one();
}
template<class T>
T TaskQue<T>::pop()
{
    unique_lock<mutex> ul(_mutex);
    while(isEmpty() && !_isExit)//set isExit to true to let the while loop exit.
    {
        _notEmpty.wait(ul);
    }
    if(_isExit)
    {
        return T{};//pop出一个标识终止的任务T;
    }
    T temp{_que.front()};
    _que.pop();
    std::cout<<"[take] TaskQue<T>::pop()"<<std::endl;
    _notFull.notify_one();
    return std::move(temp);
}
template<class T>
void TaskQue<T>::arouse()
{
    _isExit=true;
    _notEmpty.notify_all();
}

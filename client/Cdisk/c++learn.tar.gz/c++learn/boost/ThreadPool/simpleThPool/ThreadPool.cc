#include "ThreadPool.h"
#include "Task.h"
#include<iostream>
#include<unistd.h>
using std::cout;
using std::endl;
ThreadPool::ThreadPool(size_t threadNum,size_t queSize)
    :_threadNum(threadNum)
    ,_threads()
    ,_queSize(queSize)
    ,_taskQue(_queSize)
     ,_isExit(false)
{

}
ThreadPool::~ThreadPool()
{

}
//线程池启动与停止
void ThreadPool::start()
{
    for(size_t idx = 0;idx < _threadNum; ++idx)
    {
        _threads.emplace_back(&ThreadPool::doTask,this);//使用emplace_back原地构造
    }
}
void ThreadPool::stop()
{
    _isExit = true;//线程开始回收
    _taskQue.arouse();
    for(thread & worker:_threads)
    {
        worker.join();
    }
}
//添加任务与分配任务
void ThreadPool::addTask(TaskType ptask)
{
    if(ptask)
    {
        _taskQue.push(ptask);
    }

}
    ThreadPool::TaskType
ThreadPool::getTask()
{
    return _taskQue.pop();
}

//线程池交给工作线程执行的任务
void ThreadPool::doTask()
{
    while(!_isExit)
    {
        TaskType ptask=getTask();
        if(ptask==nullptr)
        {
            cout<<"isEmpty():"<<"["<<_taskQue.isEmpty()<<"]"<<"doing a task for termination!!! Tasks have been completed!"<<endl;
            sleep(1);
            continue;
        }
        ptask->process();
    }
}



#include "Task.h"
#include "TaskQueue.h"
#include "ThreadPool.h"
#include<chrono>
#include<random>
#include<iostream>
#include<memory>
#include<mutex>
using std::unique_ptr;
std::mutex mu;
int times=0;
class MyTask
:public Task
{
public:
    void process() override
    {
        ::srand(::clock());
        mu.lock();
        std::cout<<"doing something"<<"["<<::rand()%80<<"]";
        std::this_thread::sleep_for(std::chrono::milliseconds(1));
        std::cout<<"   --->done"<<std::endl;
        times++;
        mu.unlock();
    }
};
int main()
{
    ThreadPool pool(5,10);
    pool.start();
    size_t cnt=21;
    unique_ptr<Task> mt{new MyTask()};
    thread add([cnt,&pool,&mt]() mutable
               {
                    while(--cnt)
                    {
                        pool.addTask(mt.get());
                        //std::this_thread::sleep_for(std::chrono::milliseconds(200));
                    }
               });
    add.join();
    pool.stop();
    /* unique_ptr<Task> mt(new MyTask()); */
    /* while(--cnt) */
    /* { */
    /*     pool.addTask(mt.get()); */
    /* } */
    /* pool.stop(); */
    std::cout<<"[][][][]times:["<<times<<"]"<<std::endl;
    return 0;
}

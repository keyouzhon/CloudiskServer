#ifndef __taskQue_H__
#define __taskQue_H__
#include<mutex>
#include<queue>
#include<condition_variable>
#include<functional>
using std::mutex;
using std::queue;
using std::condition_variable;
using std::unique_lock;
template<class T>
class TaskQue
{
//data members
private:
    queue<T> _que;
    size_t _capacity;
    mutex _mutex;
    condition_variable _notFull;
    condition_variable _notEmpty;
    bool _isExit;
//private function - no necesscity to set as private
public:
    bool isFull();
    bool isEmpty();
//public function
public:
    TaskQue(size_t capa);
    void push(T value);
    T pop();
    void arouse();
};

#include "TaskQueue.hpp"
#endif

#pragma once

#include <vector>
#include <queue>
#include <thread>
#include <mutex>
#include <condition_variable>
#include <future>
#include <functional>
#include <stdexcept>

class ThreadPool {
public:
    /**
     * @brief 构造函数，创建并启动线程池
     * @param threads 线程池中的工作线程数量
     */
    ThreadPool(size_t threads);

    /**
     * @brief 析构函数，停止并销毁线程池
     */
    ~ThreadPool();

    /**
     * @brief 向任务队列中添加一个新任务
     * @tparam F 可调用对象的类型
     * @tparam Args 可调用对象的参数类型
     * @param f 可调用对象（函数、lambda等）
     * @param args 传递给可调用对象的参数
     * @return 返回一个 std::future 对象，用于获取任务的返回值
     */
    template<class F, class... Args>
    auto enqueue(F&& f, Args&&... args)
        -> std::future<typename std::invoke_result<F, Args...>::type>;

    // 禁止拷贝和赋值
    ThreadPool(const ThreadPool&) = delete;
    ThreadPool& operator=(const ThreadPool&) = delete;

private:
    // 存储工作线程的容器
    std::vector<std::thread> workers;
    // 任务队列
    std::queue<std::function<void()>> tasks;

    // 同步原语
    std::mutex queue_mutex;
    std::condition_variable condition;
    bool stop;
};

// --- 实现 ---

inline ThreadPool::ThreadPool(size_t threads) : stop(false) {
    if (threads == 0) {
        throw std::invalid_argument("Thread pool size cannot be zero.");
    }
    for (size_t i = 0; i < threads; ++i) {
        // 创建工作线程，并将其放入workers容器
        workers.emplace_back([this] {
            // 工作线程的无限循环
            for (;;) {
                std::function<void()> task;
                {
                    // 使用 unique_lock 来配合 condition_variable
                    std::unique_lock<std::mutex> lock(this->queue_mutex);

                    // 等待条件：stop为true或任务队列不为空
                    // wait会原子性地解锁mutex并让线程休眠，被唤醒时会重新加锁
                    this->condition.wait(lock, [this] { 
                        return this->stop || !this->tasks.empty(); 
                    });

                    // 如果线程池停止了且任务队列为空，则线程退出
                    if (this->stop && this->tasks.empty()) {
                        return;
                    }

                    // 从任务队列中取出一个任务
                    task = std::move(this->tasks.front());
                    this->tasks.pop();
                } // lock在此处被析构，互斥锁被释放

                // 执行任务
                task();
            }
        });
    }
}

template<class F, class... Args>
auto ThreadPool::enqueue(F&& f, Args&&... args)
    -> std::future<typename std::invoke_result<F, Args...>::type> {
    
    using return_type = typename std::invoke_result<F, Args...>::type;

    // 使用 packaged_task 包装任务和其返回值
    auto task = std::make_shared<std::packaged_task<return_type()>>(
        std::bind(std::forward<F>(f), std::forward<Args>(args)...)
    );

    // 获取与 packaged_task 关联的 future
    std::future<return_type> res = task->get_future();
    {
        std::lock_guard<std::mutex> lock(queue_mutex);

        // 不允许在已停止的线程池中添加新任务
        if (stop) {
            throw std::runtime_error("enqueue on stopped ThreadPool");
        }

        // 将任务（包装在lambda中）放入队列
        tasks.emplace([task]() { (*task)(); });
    }
    // 唤醒一个等待的工作线程
    condition.notify_one();
    return res;
}

inline ThreadPool::~ThreadPool() {
    {
        std::lock_guard<std::mutex> lock(queue_mutex);
        stop = true;
    }
    // 唤醒所有线程，以便它们能够检查 stop 标志并退出
    condition.notify_all();

    // 等待所有工作线程执行完毕
    for (std::thread& worker : workers) {
        worker.join();
    }
}

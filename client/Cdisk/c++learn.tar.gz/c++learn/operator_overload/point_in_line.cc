#include<iostream>
using std::ostream;
class line
{
public:
	class point{
	public:
		point(int x,int y)
		:_ix(x),_iy(y)
		{}
	friend
	ostream & operator<<(ostream & os,const line::point & rhs);
	private:
		int _ix;
		int _iy;
	};
public:
	line(int x1,int y1,int x2,int y2)
	:_pt1(x1,y1),_pt2(x2,y2)
	{}
public:
	friend
	ostream & operator<<(ostream & os,const line & rhs);
private:
	point _pt1;
	point _pt2;
};
ostream & operator<<(ostream & os,const line::point & rhs)
{
	os<<"("<<rhs._ix<<","<<rhs._iy<<")";
	return os;
}
ostream & operator<<(ostream & os,const line & rhs)
{
	os<<rhs._pt1<<"------------->"<<rhs._pt2<<std::endl;
	return os;
}
int main()
{
	
	return 0;
}


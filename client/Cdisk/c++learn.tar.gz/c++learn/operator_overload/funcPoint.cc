#include<iostream>


class fff
{
public:
	in
private:
	int x;
	int y;
	int z;
}
int main()
{
	test0();
	return 0;
}

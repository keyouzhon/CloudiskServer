#include<fstream>
#include<cstring>
#include<iostream>
int main()
{
	std::fstream ifs("for_test.txt");
	char buff[100];
	while(ifs.getline(buff,sizeof(buff)))
	{
		std::cout<<buff<<std::endl;
		std::cout<<ifs.tellg();
		std::memset(buff,0,sizeof(buff));
	
	}
	ifs.clear();//clear->seekg
	//tellg()获取游标位置会受流状态的影响（eof;
	ifs.seekg(0,std::ios::beg);
	std::cout<<"***************"<<"tellg() is:"<<ifs.tellg()<<std::endl;
	std::string line;
	while(getline(ifs,line))
	{
		std::cout<<line<<std::endl;
		std::cout<<ifs.tellg();
	}
	
	std::cout<<"&&&&&&&&&&&&&&&&&"<<std::endl;
	ifs.clear();
	//int length{ifs.tellg()};//{}列表初始化会禁止宽窄转换long->int）
	std::streamoff length{ifs.tellg()};
	char * pdata=new char[length+1]();//char数组总是要多一个“/					//0”;
	ifs.seekg(0,std::ios::beg);
	ifs.read(pdata,length);
	std::cout<<pdata;
	return 0;
}

#include "pre.hh"
#include<sstream>
text_dict* text_dict::_pinstance=nullptr;
text_dict::text_dict(ifstream & file)
{
	string line;
	while(std::getline(file,line))
		{
			std::istringstream iss(line);
			static string word="";
			while(iss>>word)
			{
				++dictionary[word];
			}
		}
}


text_dict* text_dict::getInstance()
{
	if(nullptr==_pinstance)
	{
		ifstream file("the_holy_bible.txt");
		_pinstance=new text_dict(file);
	}
	return _pinstance;
}

void text_dict::destory()
{
	if(_pinstance)
	{
		delete _pinstance;
		_pinstance=nullptr;//防止多次销毁，造成多重free;
	}
}

std::pair<string,int> text_dict::query(string word)
{
	return std::make_pair(word,dictionary[word]);
}

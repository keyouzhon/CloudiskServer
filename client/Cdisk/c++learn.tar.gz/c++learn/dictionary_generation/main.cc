#include "pre.hh"
#include<iostream>
#include<fstream>

int main()
{
	std::pair<string,int> p=text_dict::getInstance()->query("the");
	std::cout<<p.first<<":"<<p.second<<std::endl;
	return 0;
}

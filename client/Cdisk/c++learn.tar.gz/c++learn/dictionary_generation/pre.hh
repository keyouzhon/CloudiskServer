#ifndef PRE_HH
#define PRE_HH
#include<fstream>
#include<map>
#include<string>
#include<utility>
using std::string;
using std::ifstream;
class text_dict
{
	~text_dict()=default;
	text_dict(ifstream & file);
public:
	static text_dict* getInstance();
	std::pair<string,int> query(string word);
	static void destory();
private:
	std::map<string,int> dictionary;
       static text_dict * _pinstance;	
};
#endif

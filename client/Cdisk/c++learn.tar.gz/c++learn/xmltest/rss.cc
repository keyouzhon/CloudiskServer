#include "tinyxml2.h"
#include<iostream>
#include<string>
#include<vector>
#include<regex>
using namespace std;
using namespace tinyxml2;
struct rssItem
{
    string _title;
    string _link;
    string _description;
    string _content;
    rssItem(string title,string link,string description,string content)
        :_title(title),_link(link),_description(description),_content(content)
    {}
};
class rssReader
{
private:
    rssReader()
    {rss.reserve(20);}
public:
    ~rssReader()
    {}
public:
    static rssReader& getInstance()
    {
        static rssReader instance;
        return instance;
    }
    void parse(const char * file)
    {
        XMLDocument doc;
        doc.LoadFile(file);
        int id=0;
        if(doc.ErrorID())
        {
            cout<<"ErrorID()"<<doc.ErrorID()<<XMLError(doc.ErrorID())<<endl;
        }
        else
        {
            XMLElement * _item = doc.FirstChildElement("rss")->FirstChildElement("channel")->FirstChildElement("item");
            while(_item)
            {
                string title=_item->FirstChildElement("title")->GetText();
                string link=_item->FirstChildElement("link")->GetText();
                string description=_item->FirstChildElement("description")->GetText();
                string content=_item->FirstChildElement("content:encoded")->GetText();
                regex re("<.*?>");
                rss.emplace_back(title,link,regex_replace(description,re,""),regex_replace(content,re,""));
                ++id;

                _item=_item->NextSiblingElement("item");
            }
        }
    }
public:

    vector<rssItem> rss;
};
int main()
{
    rssReader curr=rssReader::getInstance();
    curr.parse("coolshell.xml");
    cout<<curr.rss[0]._description<<endl;
    return 0;
}


#include<algorithm>
#include<iostream>
#include<vector>
#include<iterator>
using std::endl;
using std::cout;
using std::cin;
using std::ostream;
using std::istream;
using std::vector;
using std::istream_iterator;
using std::ostream_iterator;
class Point
{
public:
    Point(int ix,int iy)
    :_ix(ix),_iy(iy)
    {}
    int getX()
    {
        return _ix;
    }
    int getY()
    {
        return _iy;
    }
    friend
    ostream & operator<<(ostream & os,const Point po);
private:
    int _ix;
    int _iy;
};

ostream & operator<<(ostream & os,const Point po)
{
    os<<"("<<po._ix<<","<<po._iy<<")";
    return os;
}
int main()
{
    vector<int> vec;
    //vec.reserve(10);
    istream_iterator<int> isi(cin);
    copy(isi,istream_iterator<int>(),std::back_inserter(vec));
    //copy(istream_iterator<int>(cin),istream_iterator<int>(),vec.begin());
    copy(vec.begin(),vec.end(),ostream_iterator<int>(cout,"  "));
    cout<<endl;
    return 0;
}

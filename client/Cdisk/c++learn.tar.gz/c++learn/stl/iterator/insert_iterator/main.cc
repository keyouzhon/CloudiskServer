#include<vector>
#include<list>
#include<algorithm>
#include<iterator>
#include<iostream>
using namespace std;
template<class Container>
void display(const Container & con)
{
    for(auto & ele:con)
    {
        cout<<ele<<endl;
    }
};
void test()
{

    vector<int> vec{0,1,2,3};
    list<int> li{11,23,44,44};
    //copy(li.begin(),li.end(),back_inserter(vec));
    copy(li.begin(),li.end(),back_insert_iterator<vector<int>>(vec));
    copy(vec.begin(),vec.end(),ostream_iterator<int>(cout,"  "));
    cout<<endl;
}
void test1()
{
    vector<int> vec{0,1,2,3};
    list<int> li{11,23,44,44};
    //copy(vec.begin(),vec.end(),front_inserter(li));
    copy(vec.rbegin(),vec.rend(),front_inserter(li));
    copy(li.begin(),li.end(),ostream_iterator<int>(cout,"  "));
    cout<<endl;
}
int main()
{
    //test1();
    std::cout<<"hello,world\n";
    return 0;
}

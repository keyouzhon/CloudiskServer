#include<vector>
#include<deque>
#include<list>
#include<iostream>
template<class Container>
void display(const Container & con){
    for(auto & ele:con)
    {
        std::cout<<ele<<" ";
    }
    std::cout<<std::endl;
};
int main()
{
    std::vector<int> number{1,3,5,7,83,3};
    number.pop_back();
    display(number);
    std::list<int> li{1,2,3,45,6};
    li.push_front(1000);
    display(li);

    return 0;
}

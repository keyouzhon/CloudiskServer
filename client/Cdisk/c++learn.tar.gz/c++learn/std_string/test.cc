#include "cowS_proxyPattern.hh"

#include<iostream>

int main()
{
	cowString a="hello,world";
	a[0]='H';
	std::cout<<a<<std::endl;
	cowString b(a);
	std::cout<<b<<std::endl;
	b[1]='E';
	std::cout<<b<<std::endl;
	char d=b[3];
	std::cout<<d<<std::endl;
	std::cout<<a<<std::endl;
	return 0;
}


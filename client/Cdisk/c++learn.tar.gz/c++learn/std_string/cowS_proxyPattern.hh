#ifndef COWS_PROXYPATTERN_HH
#define COWS_PROXTPATTERN_HH
#include<iostream>
#include<cstring>
using std::strlen;
using std::strcpy;
class cowString
{
private:
	char * p_str;
	static const int kRefCountLength = 4;
private:
	class charProxy
	{
	private:
		cowString & _to;
		size_t _n;
	public:
		charProxy(cowString & to,size_t n);
		~charProxy()=default;
	public:
		char operator=(char ch);
		operator char()
		{
			if(_n<_to.size())
			{
				return *(_to.p_str+_n);
			}
			else
			{
				static char nullchar='\0';
				return nullchar;
			}
		}
	friend
	std::ostream & operator<<(std::ostream & os,const cowString::charProxy & rhs);
	};
public:
	cowString();//completed
	cowString(const char* str);
	~cowString();
	cowString(const cowString & rhs);
	cowString(cowString && rhs) noexcept;
	cowString & operator=(const cowString & rhs);
	cowString & operator=(cowString && rhs) noexcept;
	const char* c_str() const
	{
		return p_str;
	}
	size_t size() const
	{
		return strlen(p_str);
	}
	charProxy operator[](size_t n);
	//friend
	//class charProxy;
	friend
	std::ostream & operator<<(std::ostream & os,const cowString::charProxy & rhs);
	friend
	std::ostream & operator<<(std::ostream & os,const cowString & rhs);
private:
	void initRefCount();//初始化引用计数
	int use_count();//返回引用计数
	static char* malloc(const char * pstr = nullptr);//分配堆空间
	void increaseRefCount();//引用加一
	void decreaseRefCount();//引用减一
	void release();//尝试回收堆空间
};
#endif

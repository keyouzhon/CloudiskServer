#include "cowS_proxyPattern.hh"
std::ostream & operator<<(std::ostream & os,const cowString & rhs)
{
	if(rhs.p_str==nullptr)
	{os<<std::endl;}
	else
	{os<<rhs.p_str;}
	return os;
}
void cowString::initRefCount()
{

	*(int*)(p_str - kRefCountLength)=1;
}
int cowString::use_count()
{
	return *(int*)(p_str - kRefCountLength);
	
}
char* cowString::malloc(const char* pstr)
{
	if(nullptr==pstr)
	{
		return new char[1+kRefCountLength]()+kRefCountLength;
	}
	else
	{
		return new char[strlen(pstr) + 1 +kRefCountLength]()+kRefCountLength;
	}
}
void cowString::increaseRefCount()
{
	++*(int*)(p_str - kRefCountLength);
}
void cowString::decreaseRefCount()
{
	--*(int*)(p_str - kRefCountLength);
}
void cowString::release()
{
	if(nullptr==p_str)
		return;
	else
	{
		decreaseRefCount();
		if(0==use_count())
		{
			delete [] (p_str-kRefCountLength);//注意()
			p_str=nullptr;//这一步没什么实际作用
			std::cout<<"---->delete heap"<<std::endl;
		}
	}
}
cowString::cowString()
:p_str(malloc())
{
	std::cout<<"cowString()"<<std::endl;
	initRefCount();
}
cowString::cowString(const char* str)
:p_str(malloc(str))
{
	strcpy(p_str,str);
	std::cout<<"cowString(const char*)"<<std::endl;
	initRefCount();
}
cowString::cowString(const cowString & rhs)
:p_str(rhs.p_str)
{
	std::cout<<"cowString(const cowString &)"<<std::endl;
	increaseRefCount();
}
cowString::cowString(cowString && rhs) noexcept
:p_str(rhs.p_str){
	std::cout<<"cowString(cowString &&)"<<std::endl;
	rhs.p_str=nullptr;//移动语义
	//increaseRefCount();
	//release();//右值销毁自动调用
}
cowString & cowString::operator=(const cowString & rhs)
{
	if(this!=&rhs)
	{
		release();
		p_str=rhs.p_str;
		increaseRefCount();
	}
	return *this;
}
cowString & cowString::operator=(cowString && rhs) noexcept
{
	if(this!=&rhs)
	{
		release();
		p_str=rhs.p_str;
		rhs.p_str=nullptr;
		//increaseRefCount();
		//release()//右值销毁自动调用
	}
}
cowString::~cowString()
{
	release();
}
cowString::charProxy cowString::operator[](size_t n)
{
	return charProxy(*this,n);
}
//charProxy的成员函数定义
cowString::charProxy::charProxy(cowString & to,size_t n)
:_to(to),_n(n)
{}
char cowString::charProxy::operator=(char ch)
{
	if(_n >= _to.size())
	{
		std::cout<<"out of range"<<std::endl;
		static char nullchar{'\0'};
		return nullchar;
	}
	if(_to.use_count()>1)
	{
		_to.decreaseRefCount();//与原始字符串分道扬镳
		char * temp=malloc(_to.c_str());//分配空间
		strcpy(temp,_to.p_str);//复制字符串内容
		_to.p_str=temp;//替换_to的p_str
		*(_to.p_str + _n)=ch;//终于在这修改p_str[_n]！！！
		_to.initRefCount();//初始化引用计数
	}
	else
	{
		*(_to.p_str + _n)=ch;
	}
	return ch;
}
std::ostream & operator<<(std::ostream & os,const cowString::charProxy & rhs)
{
	if(rhs._n<rhs._to.size())
	{
		os<<*(rhs._to.p_str + rhs._n);
	}
	else
	{
		os<<"out of range"<<std::endl;
	}
	return os;
}

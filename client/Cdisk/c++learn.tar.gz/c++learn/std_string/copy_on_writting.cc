#include<string.h>
#include<iostream>

class cowString
{
public:
	cowString();
	cowString(const char* str);
	~cowString();
	cowString(const cowString & rhs);
	cowString(cowString && rhs) noexcept;
	cowString & operator=(const cowString & rhs);
	cowString & operator=(cowString && rhs) noexcept;
	const char* c_str() const
	{
		return p_str;
	}
	size_t size() const
	{
		return strlen(p_str);
	}
	const char & operator[](size_t n) const//const成员不会修改，不需创造新的cowString
	{
		if(n<size())
		{
			return p_str[n];//p_str[n]=>*(p_str+n),返回char而不是char*;
		}
		else
		{
			std::cout<<"out of range!"<<std::endl;
				static char nullchar='\0';
				return nullchar;
		}
	}
	char & operator[](size_t n)
	{
		if(n<size())
		{
			if(use_count()>1)
			{
				decreaseRefCount();
				char * temp = malloc(p_str);
				strcpy(temp,p_str);
				p_str=temp;//改变了对象成员p_str
				initRefCount();
			}
			return p_str[n];
		}
		else
		{
			std::cout<<"out of range!"<<std::endl;
			static char nullchar='\0';
			return nullchar;
		}
	}
	friend
	std::ostream & operator<<(std::ostream & os,const cowString & rhs);
private:
	char * p_str;
	static const int kRefCountLength=4;
private:
	void initRefCount();//初始化引用计数
	int use_count();//返回引用计数
	char* malloc(const char * pstr = nullptr);//分配堆空间
	void increaseRefCount();//引用加一
	void decreaseRefCount();//引用减一
	void release();//尝试回收堆空间
};
std::ostream & operator<<(std::ostream & os,const cowString & rhs)
{
	if(rhs.p_str==nullptr)
	{os<<std::endl;}
	else
	{os<<rhs.p_str;}
	return os;
}
void cowString::initRefCount()
{

	*(int*)(p_str - kRefCountLength)=1;
}
int cowString::use_count()
{
	return *(int*)(p_str - kRefCountLength);
	
}
char* cowString::malloc(const char* pstr)
{
	if(nullptr==pstr)
	{
		return new char[1+kRefCountLength]()+kRefCountLength;
	}
	else
	{
		return new char[strlen(pstr) + 1 +kRefCountLength]()+kRefCountLength;
	}
}
void cowString::increaseRefCount()
{
	++*(int*)(p_str - kRefCountLength);
}
void cowString::decreaseRefCount()
{
	--*(int*)(p_str - kRefCountLength);
}
void cowString::release()
{
	if(nullptr==p_str)
		return;
	else
	{
		decreaseRefCount();
		if(0==use_count())
		{
			delete [] (p_str-kRefCountLength);//注意()
			p_str=nullptr;//这一步没什么实际作用
			std::cout<<"---->delete heap"<<std::endl;
		}
	}
}
cowString::cowString()
:p_str(malloc())
{
	std::cout<<"cowString()"<<std::endl;
	initRefCount();
}
cowString::cowString(const char* str)
:p_str(malloc(str))
{
	strcpy(p_str,str);
	std::cout<<"cowString(const char*)"<<std::endl;
	initRefCount();
}
cowString::cowString(const cowString & rhs)
:p_str(rhs.p_str)
{
	std::cout<<"cowString(const cowString &)"<<std::endl;
	increaseRefCount();
}
cowString::cowString(cowString && rhs) noexcept
:p_str(rhs.p_str){
	std::cout<<"cowString(cowString &&)"<<std::endl;
	rhs.p_str=nullptr;//移动语义
	//increaseRefCount();
	//release();//右值销毁自动调用
}
cowString & cowString::operator=(const cowString & rhs)
{
	if(this!=&rhs)
	{
		release();
		p_str=rhs.p_str;
		increaseRefCount();
	}
	return *this;
}
cowString & cowString::operator=(cowString && rhs) noexcept
{
	if(this!=&rhs)
	{
		release();
		p_str=rhs.p_str;
		rhs.p_str=nullptr;
		//increaseRefCount();
		//release()//右值销毁自动调用
	}
    return *this;
}
cowString::~cowString()
{
	release();
}
void test0()
{
	cowString ss;
}
cowString fun();
void test1()
{
	cowString a;
	std::cout<<a<<std::endl;
	cowString b(a);
	std::cout<<b<<std::endl;
	cowString c="hello";
	std::cout<<c<<std::endl;
	b=c;
	std::cout<<b<<std::endl;
	cowString d("world");
	std::cout<<d<<std::endl;
	cowString f(fun());
	std::cout<<f<<std::endl;
}

cowString fun()
{
	cowString temp("nihao");
	return temp;
}
int main(void)
{
	test1();
	return 0;
}

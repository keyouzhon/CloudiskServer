
#include<iostream>
#include<string>

using std::string;

class single
{
private:
	single(int pid,string name):_pid(pid),_name(name){std::cout<<"singleInstance has been created."<<std::endl;}
	~single(){std::cout<<std::endl<<"singleInstance has been destory"<<std::endl;}
	single& operator=(const single& rhs)=delete;
	single(const single& rhs)=delete;
public:
	static single* getInstance()
	{
		if(nullptr==_pinstance)
		{
			_pinstance=new single(0,"zero process");
		}
		return _pinstance;
	}
	static void destory()
	{
		if(nullptr!=_pinstance)
		{
			delete _pinstance;
			_pinstance=nullptr;
		}
	}
	void print()
	{
		std::cout<<"pid:"<<_pid<<std::endl;
		std::cout<<"name:"<<_name<<std::endl;
	}
private:
	int _pid;
	string _name;
	static single* _pinstance;
};
single*single:: _pinstance=nullptr;
int main()
{
	single* pp=single::getInstance();
	pp->print();
	single::destory();
	return 0;
}

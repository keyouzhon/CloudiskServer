#include<memory>
#include<iostream>

#define print(ss) std::cout<<ss<<std::endl
int main()
{
    std::shared_ptr<int> ss{new int(10)};
    std::shared_ptr<int> pp{ss};
    print(ss.use_count());
    print(pp.use_count());
    std::shared_ptr<int> arr[4]{ss,std::move(pp)};
    print(arr[0].use_count());
    print(arr[1].use_count());
    print(pp.use_count());
    return 0;
}

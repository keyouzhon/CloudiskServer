#include<pthread.h>
#include<iostream>
#include<string>
using std::cout;
using std::endl;
using std::string;

class singleton
{
private:
	singleton(int pid,string name):_pid(pid),_name(name){std::cout<<"singleInstance has been created."<<std::endl;}
	~singleton(){std::cout<<std::endl<<"singleInstance has been destory"<<std::endl;}
	singleton& operator=(const singleton& rhs)=delete;
	singleton(const singleton& rhs)=delete;
public:
	static singleton* getInstance()
	{
		pthread_once(&_once,init);
		return _pinstance;
	}
	static void init()
	{
		_pinstance=new singleton(1,"main()");
		atexit(destory);
	}
	static void destory()
	{
		if(nullptr!=_pinstance)
		{
			delete _pinstance;
			_pinstance=nullptr;
		}
	}
	void print()
	{
		std::cout<<"pid:"<<_pid<<std::endl;
		std::cout<<"name:"<<_name<<std::endl;
	}
private:
	int _pid;
	string _name;
	static singleton* _pinstance;
	static pthread_once_t _once;
};
singleton* singleton:: _pinstance=nullptr;
pthread_once_t singleton::_once=PTHREAD_ONCE_INIT;

int main()
{
	singleton::getInstance()->print();

	return 0;
}

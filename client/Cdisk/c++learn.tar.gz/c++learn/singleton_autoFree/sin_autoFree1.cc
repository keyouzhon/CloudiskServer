#include<iostream>
#include<string>
using std::cout;
using std::endl;
using std::string;

class singleton
{
public:
	class AutoRelease
	{
	public:
		AutoRelease()
		{}
		~AutoRelease()
		{
			if(_pinstance)
			{
				delete _pinstance;
				_pinstance=nullptr;
			}

		}
	};
private:
	singleton(int pid,string name):_pid(pid),_name(name){std::cout<<"singleInstance has been created."<<std::endl;}
	~singleton(){std::cout<<std::endl<<"singleInstance has been destory"<<std::endl;}
	singleton& operator=(const singleton& rhs)=delete;
	singleton(const singleton& rhs)=delete;
public:
	static singleton* getInstance()
	{
		if(nullptr==_pinstance)
		{
			_pinstance=new singleton(0,"zero process");
		}
		return _pinstance;
	}
	static void destory()
	{
		if(nullptr!=_pinstance)
		{
			delete _pinstance;
			_pinstance=nullptr;
		}
	}
	void print()
	{
		std::cout<<"pid:"<<_pid<<std::endl;
		std::cout<<"name:"<<_name<<std::endl;
	}
private:
	int _pid;
	string _name;
	static singleton* _pinstance;
};
singleton* singleton:: _pinstance=nullptr;
void test0(){
    
    singleton::getInstance()->print();
}
int main()
{
	test0();
	return 0;
}

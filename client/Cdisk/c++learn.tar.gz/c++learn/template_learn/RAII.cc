#include<iostream>
#include<cstring>

template<class T>
class RAII
{
public:
    RAII(T * t)
    :_pT(t)
    {}
    ~RAII()//RAII<T>或者RAII都是可以写的
    {
        if(_pT)
        {
            delete _pT;
            _pT=nullptr;
        }
    }
    T * operator->()
    {
        return _pT;
    }
    T & operator*()
    {
        return *_pT;
    }
private:
    T * _pT;
    RAII(const RAII<T> & rhs)=delete;
    RAII(RAII<T>&& rhs) = delete;
    RAII<T>& operator=(const RAII<T> & rhs)=delete;
    RAII<T>& operator=(RAII<T>&& rhs)=delete;
};
class String
{
public:
    String(const char* str)
    :p_str(new char[strlen(str)+1])
    {
       strcpy(p_str,str);
        std::cout<<"String(const char*)"<<std::endl;
    }
    String(const String & rhs)
    :p_str(new char[strlen(rhs.p_str)+1])
    {
        strcpy(p_str,rhs.p_str);
        std::cout<<"string(const String &)"<<std::endl;
    }
    //string(const String & rhs)
    //:String(rhs.p_str){}
    
    String & operator=(const String & rhs)
    //:String(rhs.p_str)//only constructors can take base initializer
    {
        if(this==&rhs)
        {
            return *this;
        }
        using std::swap;
        String temp(rhs);
        std::swap(p_str,temp.p_str);
        std::cout<<"string& operator=(ks&)"<<std::endl;
        return *this;
    }
    String & operator=(String&& rhs)
    {
        if(this==&rhs)
        {
            return *this;
        }
        using std::swap;
        std::swap(p_str,rhs.p_str);
        rhs.p_str=nullptr;
        std::cout<<"string& operator=(String&&)"<<std::endl;
    }
public:
    void print()
    {
        std::cout<<p_str<<std::endl;
    }
private:
    char* p_str;
};
int main()
{
    RAII<int> pp{new int(10)};
    std::cout<<*pp<<std::endl;
    
    RAII<String> ss{new String{"hello,world!!"}};
    ss->print();
    String uu=*ss;
    RAII<String> DD{new String{"tanxianyu"}};
    DD->print();
    std::cout<<"------->>>>";
    return 0;
}

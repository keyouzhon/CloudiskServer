#include<set>
#include<iostream>
template<class T>
T add(T t1,T t2)
{
    return t1+t2;
}
std::set<int> operator+(const std::set<int> & s1,const std::set<int> & s2)
{
    std::set<int> temp(s1.begin(),s1.end());
    temp.insert(s2.begin(),s2.end());
    return temp;
}
void print()
{
    std::cout<<std::endl;
}
template <class T,class ...Args>
void print(T t1,Args ...args){
    std::cout<<t1<<"-->";
    print(args...);
}
int main()
{
    std::set<int> a{1,2,3,4};
    std::set<int> b{6,7,8,9};
    std::set<int> c{add(a,b)};
    for(auto & m:c)
    {
        std::cout<<m<<"---";
    }
    std::cout<<std::endl;
    print(2,0,2,5,"hello","world","!",2);
    print("hello","world","!",1916);
    return 0;
}

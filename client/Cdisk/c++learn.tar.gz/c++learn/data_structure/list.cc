#include<iostream>
using namespace std;
//define the node structure 
template<class Value_Type>
struct node
{
    using vt=Value_Type;
     vt _value;
    node* _next;
    node(vt value):_value(value),_next(nullptr){}
    node():_value(0),_next(nullptr){}//用于front()返回空节点;
};

//define the list structure
template<class Value_Type>
class list
{
    using vt=Value_Type;
public:
    list()
    :_head(nullptr),_size(0)
    {
        std::cout<<"list has been created."<<std::endl;
    }
    ~list()
    {
        while(_size!=0)
        {
            cout<<"one node has been destoryed"<<endl;
            node<vt>* temp=_head->_next;
            delete _head;
            _head=temp;
            --_size;
        }
        //(_head==nullptr) is true;
    }
    size_t size() {return _size;}
    list& push_front(const vt x)
    {
        ++_size;
        node<vt>* temp(new node<vt>(x));
        temp->_next=_head;
        _head=temp;
        return *this;
    }
    node<vt>& front()
    {
        if(_head==nullptr)
        {
            static node<vt> nullNode{};
            return nullNode;
        }
        return *(_head);
    }
    void  pop_front()
    {
        if(_head==nullptr)
            std::cout<<"null list";
        else
        {
            node<vt>* temp=_head->_next;
            delete _head;
            _head=temp;
            --_size;
        }
    }

private:
    size_t _size;
    node<Value_Type>* _head;
};

int main()
{
    list<int> ll{};
    cout<<"1111"<<endl;
    ll.push_front(10).push_front(20).push_front(30);
    cout<<"2222"<<endl;
    std::cout<<ll.front()._value<<std::endl;
    return 0;
}

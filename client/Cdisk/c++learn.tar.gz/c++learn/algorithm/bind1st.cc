#include<iostream>
#include<vector>
#include<algorithm>
#include<iterator>
using namespace std;
int main()
{
    vector<int> vec{1,2,3,4,54,1,312,4,24,12,3,1,3,3};
    auto display=[](const vector<int> & vec)
    {
        copy(vec.begin(),vec.end(),ostream_iterator<int>(cout,"  "));
        cout<<endl;
    };
    display(vec);
    auto it=remove_if(vec.begin(),vec.end(),bind1st(less<int>(),2));
    vec.erase(it,vec.end());
    display(vec);
    return 0;
}

#include<algorithm>
#include<deque>
#include<iostream>
#include<iterator>
using std::remove_if;
using std::endl;
using std::cout;
using std::ostream_iterator;
using std::copy;
using std::deque;
int main()
{
    deque<int> de{1,3,5,2,4,5,87,9,0,1,6};
    auto print=[](const deque<int> & temp)
    {
        copy(temp.begin(),temp.end(),ostream_iterator<int>(cout,"  "));
        cout<<endl;
    };
    print(de);
    deque<int>::iterator it=remove_if(de.begin(),de.end(),[](int value)->bool
              {
              return value>4;
              }
              );
    de.erase(it,de.end());
    print(de);
    return 0;
}

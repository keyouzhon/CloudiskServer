#include<iostream>
#include<cstring>
class cl
{
public:
	int   _number;
	static char* _content;
public:
	//构造函数
	cl(int number,const char * content="佚名")
	:_number(number)
	{
		size_t len=std::strlen(content)+1;
		_content=new char[len];
		std::strcpy(_content,content);
	}
	//析构函数
	~cl()
	{
		if(nullptr!=_content)
		{
			delete [] _content;
			_content=nullptr;
			std::cout<<"~cl析构函数调用"<<std::endl;
		}

	}
};
int main()
{
	//析构函数负责清除cl类数据成员申请的堆空间，数据成员本身由编译器销毁
	{
	cl test(3,"thisname"); 
	test.~cl();//不建议手动调用析构函数，这里由于析构函数中——content=nullptr,所以没问题
	//出了}后test这个实例就被编译器消灭了
	if(cl::_content==nullptr)
	{
		std::cout<<"静态数据成员的作用域是类作用域；生命周期是程序级别"<<std::endl;
	}
	return 0;
}

#ifndef MYLOGGER_HH
#define MYLOGGER_HH
#include<log4cpp/Category.hh>
#include<string>
using std::string;
#define addPrefix(msg) string("[").append(__FILE__).append(":").append(__func__).append("]").append(msg).c_str()
#define logInfo(msg) mylogger::getInstance()->info(addPrefix(msg))
//warn
//debug
//error...
class mylogger
{
public:
	void warn(const char *msg);
	void error(const char*msg);
	void debug(const char*msg);
	void info(const char *msg);
private:
	mylogger();
	~mylogger();
public:
	static mylogger* getInstance();
	static void destory();
private:
	log4cpp::Category & _mycat;
	static mylogger* _pinstance;
};
#endif

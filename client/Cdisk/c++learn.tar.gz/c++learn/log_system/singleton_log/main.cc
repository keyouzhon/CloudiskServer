#include "mylogger.hh"
#include<iostream>
#include<string>
using std::cout;
using std::endl;

void test0()
{
	mylogger::getInstance()->debug("this is a debug message.");
}
void test1()
{
	mylogger::getInstance()->debug(addPrefix("this is a message"));
}
void test2()
{
	logInfo("The log is info message.");
}
int main()
{
	test2();
	return 0;
}

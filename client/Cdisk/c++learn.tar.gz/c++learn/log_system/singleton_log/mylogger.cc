#include "mylogger.hh"
#include<iostream>
#include<log4cpp/Priority.hh>
#include<log4cpp/PatternLayout.hh>
#include<log4cpp/OstreamAppender.hh>
#include<log4cpp/FileAppender.hh>
using std::cout;
using std::endl;
using namespace log4cpp;

mylogger* mylogger::_pinstance=nullptr;

mylogger::mylogger()
:_mycat(Category::getRoot().getInstance("mycat"))
{
	auto ptn1= new PatternLayout();
	ptn1->setConversionPattern("%d %c [%p] %m%n");
	
	auto ptn2= new PatternLayout();
	ptn1->setConversionPattern("%d %c [%p] %m%n");
	
	auto pos = new OstreamAppender("console",&cout);
	pos->setLayout(ptn1);

	auto pfil= new FileAppender("file","this.log");
	pfil->setLayout(ptn2);

	_mycat.setPriority(Priority::DEBUG);
	_mycat.addAppender(pos);
	_mycat.addAppender(pfil);

	cout<<"mylogger()"<<endl;

}

mylogger::~mylogger()
{
	Category::shutdown();
	cout<<"~mylogger"<<endl;
}
mylogger* mylogger::getInstance()
{
	if(nullptr==_pinstance)
	{
		_pinstance=new mylogger();
	}
	return _pinstance;
}

void mylogger::destory()
{
	if(_pinstance)
	{
		delete _pinstance;
		_pinstance=nullptr;
	}
}

void mylogger::warn(const char *msg)
{
	_mycat.warn(msg);
}
void mylogger::error(const char *msg)
{
	_mycat.error(msg);
}
void mylogger::debug(const char *msg)
{
	_mycat.debug(msg);
}
void mylogger::info(const char *msg)
{
	_mycat.info(msg);
}

#include<iostream>
#include<log4cpp/RollingFileAppender.hh>
#include<log4cpp/OstreamAppender.hh>
#include<log4cpp/PatternLayout.hh>
#include<log4cpp/FileAppender.hh>
#include<log4cpp/Priority.hh>
#include<log4cpp/Category.hh>
using std::cout;
using std::endl;
using namespace log4cpp;

void test0()
{
    //1.设置布局
    PatternLayout *ptn1 = new PatternLayout();
    ptn1->setConversionPattern("%d %c [%p] %m%n");
    
    PatternLayout *ptn2 = new PatternLayout();
    ptn2->setConversionPattern("%d %c [%p] %m%n");

    PatternLayout *ptn3 = new PatternLayout();
    ptn3->setConversionPattern("%d %c [%p] %m%n");
    //2.设置目的地
    OstreamAppender * pos = new OstreamAppender("console",&cout);
    pos->setLayout(ptn1);

    FileAppender * filePos = new FileAppender("file","today.log");
    filePos->setLayout(ptn2);

    RollingFileAppender *RollPos = new RollingFileAppender("RollingFile","log.log",5*1024,9);
    RollPos->setLayout(ptn3);



    //3.创建记录器
    Category & cat = Category::getInstance("cat");
    cat.setPriority(Priority::DEBUG);
    cat.addAppender(pos);
    cat.addAppender(filePos);
    cat.addAppender(RollPos);

    int count=0;
    while(count++<100)
    {
    cat.emerg("this is an emerge msg");
    cat.fatal("this is an fatal msg");
    cat.alert("this is a alert msg");
    cat.crit("this is a crit msg");
    cat.error("this is an error msg");
    }
    
    Category::shutdown();
}
int main()
{

	test0();
	return 0;
}

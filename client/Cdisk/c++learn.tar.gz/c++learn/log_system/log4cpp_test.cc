#include "log4cpp/Category.hh"
#include "log4cpp/Appender.hh"
#include "log4cpp/FileAppender.hh"
#include "log4cpp/OstreamAppender.hh"
#include "log4cpp/Layout.hh"
#include "log4cpp/BasicLayout.hh"
#include "log4cpp/Priority.hh"
int main(int argc, char** argv) {
    //ostramAppender构造函数的第一个参数代表目的地的名字（仅作指示）
    //第二个参数是一个ostream&，决定目的地--（&cout）
	log4cpp::Appender *appender1 = new log4cpp::OstreamAppender("console", &std::cout);
    //绑定ostream目的地与日志格式(BasicLayout())
	appender1->setLayout(new log4cpp::BasicLayout());

	log4cpp::Appender *appender2 = new log4cpp::FileAppender("default", "program.log");
    //绑定ofstream目的地与日志格式（BasicLayout())
    appender2->setLayout(new log4cpp::BasicLayout());
    //getRoot()创建出一个root级别的Category对象(记录器对象)
	log4cpp::Category& root = log4cpp::Category::getRoot();
    //root设置优先级为WARN级别（日志系统优先级，理解为门槛）
	root.setPriority(log4cpp::Priority::WARN);
    //root设置目的地--输出到终端
	root.addAppender(appender1);

    //getInstance创建一个名为sub1的叶子级别的Category对象
    //sub1继承了root的优先级和目的地
	log4cpp::Category& sub1 = log4cpp::Category::getInstance(std::string("sub1"));
    //在输出到终端的基础上，由将日志信息保存到文件
	sub1.addAppender(appender2);

	// use of functions for logging messages
	root.error("root error");//error函数决定了这条日志信息的优先级为ERROER
	root.info("root info");//info<error,被过滤
	sub1.error("sub1 error");//输出到终端并保存到文件
	sub1.warn("sub1 warn");//同上

	// printf-style for logging variables
	root.warn("%d + %d == %s ?", 1, 1, "two");

	// use of streams for logging messages
	root << log4cpp::Priority::ERROR << "Streamed root error";//终端
	root << log4cpp::Priority::INFO << "Streamed root info";//pass
	sub1 << log4cpp::Priority::ERROR << "Streamed sub1 error";//终端以及文件
	sub1 << log4cpp::Priority::WARN << "Streamed sub1 warn";//文件以及终端

	// or this way:
	root.errorStream() << "Another streamed error";//终端

	return 0;
}

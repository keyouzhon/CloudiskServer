#include<iostream>
using std::ostream;
class Line
{
public:
	//Point称为Line的成员类型
	class Point
	{
	public:
		Point(int x=0,int y=0)
			:_ix(x),_iy(y)
		{
			std::cout<<"Point(int,int)"<<std::endl;
		}
		~Point()
		{
			std::cout<<"~Point()"<<std::endl;
		}
		void print()
		{
			std::cout<<"("<<_ix<<","<<_iy<<")";
		}
	//这里的友元声明是为了，在外部能通过Line::Point访问Point对象的私有成员
	friend
	ostream & operator<<(ostream& os,Line::Point & rhs);
	private:
		int _ix;
		int _iy;
		static int _iz;

	};
public:
	Line(int x1,int y1,int x2,int y2)
		:_pt1(x1,y1),_pt2(x2,y2)
	{
		std::cout<<"Line()"<<std::endl;
	}
	~Line()
	{
		std::cout<<"~Line()"<<std::endl;
	}
	void LinePrint()
	{
		_pt1.print();
		std::cout<<"------>";
		_pt2.print();
		std::cout<<std::endl;
	
	}
	//这里的友元声明是为了，在Line定义外部能够访问Line的成员类型Point
	friend
	ostream & operator<<(ostream & os,Line::Point & rhs);
	//这里的友元声明是为了，在Line定义外部能够访问Line对象
	friend
	ostream & operator<<(ostream & os,Line& rhs);
	
private:
	Point _pt1;
	Point _pt2;

	
};
//内部类的静态数据成员必须放在外部类下面定义；
int Line::Point::_iz=0;

ostream & operator<<(ostream& os,Line::Point & rhs)
{
	os<<"("<<rhs._ix<<","<<rhs._iy<<")";
	return os;
}

ostream & operator<<(ostream& os,Line & rhs)
{
	os<<rhs._pt1<<"--------->"<<rhs._pt2<<std::endl;
	return os;
}
void test0()
{
	std::cout<<sizeof(Line::Point)<<std::endl;
}
void test1()
{
	Line ll(1,2,3,4);
	std::cout<<ll<<std::endl;
}
int main()
{
	//test0();
	test1();
	return 0;
}

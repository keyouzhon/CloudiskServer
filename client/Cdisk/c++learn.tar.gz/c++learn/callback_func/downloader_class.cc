#include <iostream>
#include <string>
#include "FileProcessor.h"
class Downloader 
{
public:
	void startDownload(
			FileProcessor* processor,

}


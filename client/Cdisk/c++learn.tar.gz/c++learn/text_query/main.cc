#include "textQuery.hh"

int main(int argc,char ** argv)
{
    if(argc==1)
    {
        cout<<"missing parameter"<<endl;
        return 0;
    }
    {
        textSource initializer;
        initializer.process(argv[1]);//construct static members: _sentence,_word_set
    }
    //baseQuery q("the");
    //q.print();
    Query q=Query("green")&Query("tree");
    q.print();
    return 0;
}

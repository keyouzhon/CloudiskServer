#include "textQuery.hh"
#include<vector>
#include<map>
#include<memory>
#include<iostream>



#include<iostream>
#include<vector>
#include<map>
#include<set>
#include<memory>
#include<string>
#include<fstream>
#include<sstream>
#include<algorithm>
using namespace std;

//word : line
//line : string
class textSource
{
public:
    void process(string file)
    {
        _file=file;
        ifstream io(_file);
        if(!io.is_open())
        {
            cout<<"can not open this file!";
        }
        else
        {
            string line;
            int count=-1;
            while(getline(io,line))
            {
                _sentence.push_back(line);
                ++count;
                istringstream is(line);
                string word;
                while(is>>word)
                {
                    _word_set[word].insert(count);
                }
            }
            _line_max=_sentence.size();
        }
    }
protected:
    static string _file;
    static vector<string> _sentence;
    static map<string,set<int>> _word_set;
    static int _line_max;
};
vector<string> textSource::_sentence;
map<string,set<int>> textSource::_word_set;
string textSource::_file;
int textSource::_line_max;

class baseQuery:public textSource
{
public:
    baseQuery(string word)
    :_query_word(word)
    {}
    void print()
    {
        for(auto & element:_word_set[_query_word])
        {
            cout<<"line:"<<element+1<<")--->"<<_sentence[element]<<endl;
        }
        cout<<"total occurrence times:"<<_word_set[_query_word].size()<<endl;
    }
private:
    string _query_word;
};

class Query:public textSource
{
public:
    friend Query operator~(Query && rhs);
    friend Query operator&(Query && lhs,Query && rhs);
    friend Query operator|(Query && lhs,Query && rhs);
public:
    Query(set<int> result_set)
    :_result_set(result_set)
    {

    }
    Query(string word)
    {
        _result_set=_word_set[word];
    }
    //virtual ~Query() {}
    void print()
    {
        for(int element:_result_set)
        {
            cout<<"line:"<<element<<":>"<<_sentence[element]<<endl;
        }
        cout<<"total occurence times:"<<_result_set.size()<<endl;
    }
protected:
    set<int> _result_set;
};

class reQuery:public Query
{

};
class binQuery:public Query
{

};
class andQuery:public binQuery
{

};
class orQuery:public binQuery
{

};

set<int> find_difference(int max,const set<int> & s);
Query operator~(Query && rhs)
{
    return Query(find_difference(rhs._line_max,rhs._result_set));
}
Query operator&(Query && lhs,Query && rhs)
{
    set<int> temp;
    set_intersection(
        lhs._result_set.begin(),lhs._result_set.end(),
        rhs._result_set.begin(),rhs._result_set.end(),
        inserter(temp,temp.begin()));
    return Query(temp);
}
Query operator|(Query && lhs,Query && rhs)
{
    set<int> temp;
    set_union(
        lhs._result_set.begin(),lhs._result_set.end(),
        rhs._result_set.begin(),rhs._result_set.end(),
        inserter(temp,temp.begin()));
    return Query{temp};
}
//find the complement
set<int> find_difference(int max,const set<int> & s)
{
    set<int> result{};
    int pre_val=0;
    for(auto & element:s)
    {
        for(;pre_val<element;++pre_val)
        {
            result.insert(pre_val);
        }
        ++pre_val;
    }
    for(int i=pre_val;i<=max;++i)
    {
        result.insert(i);
    }
    return result;
}

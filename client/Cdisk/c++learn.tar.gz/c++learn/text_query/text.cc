#include<iostream>
#include<map>
#include<set>
using namespace std;
int main()
{
    map<const char *,set<int>> mp;
    cout<<typeid(mp["word"].insert(0)).name()<<endl;
}
